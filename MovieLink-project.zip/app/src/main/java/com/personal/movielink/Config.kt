package com.personal.movielink

object Config {
    // Change this if the site moves to a new address
    const val HOME_URL = "https://ss257n.movielinkbd.at/"

    // Hosts ending with any of these count as "the site" (never blocked, stay inside the app)
    val INTERNAL_SUFFIXES = listOf("movielinkbd.at")

    fun isInternal(host: String?): Boolean =
        host != null && INTERNAL_SUFFIXES.any { host == it || host.endsWith(".$it") }
}
