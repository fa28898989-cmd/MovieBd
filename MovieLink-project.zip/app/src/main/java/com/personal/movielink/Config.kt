package com.personal.movielink

object Config {
    // Change this if the site moves to a new address
    const val HOME_URL = "https://ss257n.movielinkbd.at/"

    // Hosts ending with any of these count as "the site" (never blocked, stay inside the app)
    val INTERNAL_SUFFIXES = listOf("movielinkbd.at")

    // Download apps to hand files to, tried in order (first one installed wins).
    // If none is installed, the app falls back to Android's built-in downloader.
    val DOWNLOAD_APPS = listOf(
        "idm.internet.download.manager.plus",
        "idm.internet.download.manager",
        "idm.internet.download.manager.adm.lite"
    )

    fun isInternal(host: String?): Boolean =
        host != null && INTERNAL_SUFFIXES.any { host == it || host.endsWith(".$it") }
}
