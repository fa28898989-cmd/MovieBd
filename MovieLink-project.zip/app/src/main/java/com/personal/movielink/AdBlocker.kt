package com.personal.movielink

import android.net.Uri

object AdBlocker {
    // Add more ad/tracker domains here whenever you spot one. Subdomains are matched automatically.
    private val domains = hashSetOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com", "2mdn.net",
        "popads.net", "popcash.net", "propellerads.com", "propellerclick.com", "exoclick.com",
        "exosrv.com", "exdynsrv.com", "juicyads.com", "trafficjunky.com", "trafficfactory.biz",
        "adsterra.com", "highperformanceformat.com", "effectivegatecpm.com", "profitablecpmrate.com",
        "profitablegatecpm.com", "highcpmgate.com", "adcash.com", "clickadu.com", "hilltopads.net",
        "hilltopads.com", "onclickads.net", "onclkds.com", "a-ads.com", "adnxs.com", "taboola.com",
        "outbrain.com", "mgid.com", "revcontent.com", "bidvertiser.com", "ad-maven.com",
        "admaven.com", "richads.com", "monetag.com", "pushame.com", "pushails.com", "notifpush.com",
        "adskeeper.com", "adspyglass.com", "ero-advertising.com", "tsyndicate.com", "ads.yahoo.com",
        "histats.com", "mc.yandex.ru", "adform.net", "criteo.com", "pubmatic.com", "rubiconproject.com",
        "openx.net", "smaato.net", "yllix.com", "kdmzu.com", "realsrv.com", "syndication.realsrv.com",
        "bongacams.com", "stripchat.com", "chaturbate.com", "livejasmin.com", "adtng.com",
        "clksite.com", "tzegilo.com", "acscdn.com", "wpadmngr.com", "pemsrv.com"
    )

    private val patterns = listOf(
        "popunder", "/adserver", "adsbygoogle", "/pop.js", "/popup.js", "/banner_ads", "/prebid"
    )

    fun shouldBlock(uri: Uri): Boolean {
        val host = uri.host?.lowercase() ?: return false
        if (Config.isInternal(host)) return false
        var h = host
        while (true) {
            if (h in domains) return true
            val i = h.indexOf('.')
            if (i < 0) break
            h = h.substring(i + 1)
        }
        val s = uri.toString().lowercase()
        return patterns.any { s.contains(it) }
    }
}
