package com.personal.movielink

object Cosmetic {
    // Dummy window so ad scripts think the popup opened and don't fall back to redirecting the page
    private val POPUP_JS = """
window.open=function(){return {closed:false,focus:function(){},blur:function(){},close:function(){},postMessage:function(){},document:{write:function(){},close:function(){}},location:{href:''}};};
""".trimIndent()

    // AMOLED theme for the movie site: page -> pure #000000, cards -> very subtle dark layers.
    // Only touches neutral dark backgrounds (badges, buttons, images keep their colours).
    // Light pages (download pages) are detected and left completely untouched.
    private val AMOLED_JS = """
(function(){
  var H='__HOSTS__'.split(','),h=location.hostname,ok=false;
  for(var i=0;i<H.length;i++){if(h===H[i]||h.endsWith('.'+H[i]))ok=true;}
  if(!ok||window.__amo)return; window.__amo=1;
  var C=['#000000','#0a0a0a','#111111','#181818'];
  var PL=/player|plyr|jwplayer|jw-|vjs|embed/i;
  var st=document.createElement('style');
  st.textContent='html,body{background:#000!important}video{background:#000!important}'
    +':fullscreen{background:#000!important}:-webkit-full-screen{background:#000!important}';
  document.documentElement.appendChild(st);
  var off=false,mods=[];
  function report(l){try{AmoledBridge.light(l);}catch(e){}}
  function setBg(el,c){
    if(el.__pb===undefined)el.__pb=[el.style.getPropertyValue('background-color'),el.style.getPropertyPriority('background-color')];
    el.style.setProperty('background-color',c,'important');
    mods.push(el);
  }
  function revert(){
    for(var i=0;i<mods.length;i++){
      var e=mods[i],p=e.__pb; if(!p)continue;
      if(p[0])e.style.setProperty('background-color',p[0],p[1]); else e.style.removeProperty('background-color');
    }
    mods=[];
  }
  function up(el){var p=el.parentElement;while(p){if(p.__lv!==undefined)return p.__lv;p=p.parentElement;}return -1;}
  function decide(el){
    if(el.__pl===undefined){
      var pp=el.parentElement;
      el.__pl=!!((pp&&pp.__pl)||el.tagName==='VIDEO'||el.tagName==='IFRAME'||PL.test((el.getAttribute('class')||'')+' '+(el.id||'')));
    }
    if(el.__done)return null;
    if(el===document.body||el===document.documentElement){el.__lv=0;el.__done=1;return null;}
    var cs=getComputedStyle(el),m=cs.backgroundColor.match(/[\d.]+/g);
    if(!m||m.length<3)return null;
    var a=m.length>3?+m[3]:1;
    if(a===0)return null;
    el.__done=1;
    var r=+m[0],g=+m[1],b=+m[2];
    el.__ob=[r,g,b,a];
    if(a<0.95)return null;
    var lum=0.299*r+0.587*g+0.114*b;
    if(Math.max(r,g,b)-Math.min(r,g,b)>48||lum>110)return null;
    var l;
    if(el.__pl){l=0;}
    else{
      var rc=el.getBoundingClientRect(),pl=up(el);
      if(rc.width>=innerWidth*0.95&&(rc.height>=innerHeight*0.5||lum<20))l=0;
      else if(pl<0)l=1;
      else l=Math.min(pl+1,3);
      if((cs.position==='fixed'||cs.position==='sticky')&&rc.top<=1)l=0;
    }
    el.__lv=l;
    return C[l];
  }
  function fixVideos(){
    var vs=document.querySelectorAll('video'),w=[];
    for(var i=0;i<vs.length;i++){
      var p=vs[i].parentElement;
      while(p&&p!==document.body&&p!==document.documentElement){
        if(!p.__vb){
          p.__vb=1;
          var m=getComputedStyle(p).backgroundColor.match(/[\d.]+/g);
          if(m&&m.length>=3){
            var a=m.length>3?+m[3]:1,r=+m[0],g=+m[1],b=+m[2];
            if(a>=0.95&&(r+g+b)>0&&Math.max(r,g,b)-Math.min(r,g,b)<=48&&0.299*r+0.587*g+0.114*b<=110)w.push(p);
          }
        }
        p=p.parentElement;
      }
    }
    for(var j=0;j<w.length;j++)setBg(w[j],'#000000');
  }
  function run(list){
    if(off)return;
    var w=[];
    for(var i=0;i<list.length;i++){var c=decide(list[i]);if(c)w.push(list[i],c);}
    for(var j=0;j<w.length;j+=2)setBg(w[j],w[j+1]);
    fixVideos();
  }
  function collect(root,out){
    if(root.nodeType!==1)return;
    out.push(root);
    var d=root.querySelectorAll('*');
    for(var i=0;i<d.length;i++)out.push(d[i]);
  }
  function all(){var o=[];collect(document.documentElement,o);run(o);}
  function origRgb(el){
    var o=el.__ob;
    if(!o){
      var m=getComputedStyle(el).backgroundColor.match(/[\d.]+/g);
      if(!m||m.length<3)return null;
      o=[+m[0],+m[1],+m[2],m.length>3?+m[3]:1];
    }
    return o;
  }
  function pageLum(){
    var es=[document.body,document.documentElement];
    for(var i=0;i<es.length;i++){
      if(!es[i])continue;
      var m=getComputedStyle(es[i]).backgroundColor.match(/[\d.]+/g);
      if(m&&m.length>=3){var a=m.length>3?+m[3]:1;if(a>=0.5)return 0.299*+m[0]+0.587*+m[1]+0.114*+m[2];}
    }
    return 255;
  }
  // Light page (e.g. download page)? then undo everything and stay out of the way
  function check(){
    if(off)return;
    st.disabled=true;
    var pg=pageLum(),pts=[[.5,.2],[.5,.5],[.5,.8],[.2,.5],[.8,.5]],light=0;
    for(var i=0;i<pts.length;i++){
      var el=document.elementFromPoint(innerWidth*pts[i][0],innerHeight*pts[i][1]),v=-1;
      while(el&&el!==document.body&&el!==document.documentElement){
        var o=origRgb(el);
        if(o&&o[3]>=0.5){v=0.299*o[0]+0.587*o[1]+0.114*o[2];break;}
        el=el.parentElement;
      }
      if(v<0)v=pg;
      if(v>160)light++;
    }
    st.disabled=false;
    if(light>=3){off=true;revert();st.remove();report(true);}
    else report(false);
  }
  window.__amoRun=function(){if(!off)all();};
  var q=[],t=0;
  new MutationObserver(function(ms){
    if(off)return;
    for(var i=0;i<ms.length;i++){var n=ms[i].addedNodes;for(var j=0;j<n.length;j++)q.push(n[j]);}
    if(!t)t=requestAnimationFrame(function(){
      t=0;var o=[],n=q.splice(0);
      for(var k=0;k<n.length;k++)collect(n[k],o);
      run(o);
    });
  }).observe(document.documentElement,{childList:true,subtree:true});
  function fs(){if(!off)fixVideos();}
  document.addEventListener('fullscreenchange',fs);
  document.addEventListener('webkitfullscreenchange',fs);
  window.addEventListener('load',function(){
    all();setTimeout(check,50);
    setTimeout(function(){all();check();},900);
  });
})();
""".trimIndent().replace("__HOSTS__", Config.INTERNAL_SUFFIXES.joinToString(","))

    val EARLY_JS = POPUP_JS + "\n" + AMOLED_JS

    // Runs after load: hide leftover ad boxes and remove invisible click-hijack overlays.
    // Only checks newly added elements, so it stays light.
    val PAGE_JS = """
(function(){
  if(window.__amoRun)window.__amoRun();
  if(window.__abk)return; window.__abk=1;
  var st=document.createElement('style');
  st.textContent='ins.adsbygoogle,[id^="google_ads"],[class*="popunder"],[id*="popunder"],'
   +'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="adsterra"],'
   +'div[id^="ad-"],div[class^="ad-"],.ad-banner,.ads-banner,.adsbox{display:none!important}';
  (document.head||document.documentElement).appendChild(st);
  function chk(e){
    if(e.nodeType!==1)return;
    var cs=getComputedStyle(e);
    if(cs.position!=='fixed'&&cs.position!=='absolute')return;
    if((parseInt(cs.zIndex)||0)<1000)return;
    var r=e.getBoundingClientRect();
    if(r.width>=innerWidth*0.9&&r.height>=innerHeight*0.9&&e.textContent.trim()===''&&!e.querySelector('video,img,canvas'))e.remove();
  }
  function scan(root){
    chk(root);
    if(root.querySelectorAll){var l=root.querySelectorAll('div,a,span');for(var i=0;i<l.length&&i<300;i++)chk(l[i]);}
  }
  var q=[],t=null;
  new MutationObserver(function(ms){
    for(var i=0;i<ms.length;i++){var n=ms[i].addedNodes;for(var j=0;j<n.length;j++)q.push(n[j]);}
    if(!t)t=setTimeout(function(){t=null;var n=q.splice(0);for(var k=0;k<n.length;k++)scan(n[k]);},300);
  }).observe(document.documentElement,{childList:true,subtree:true});
  scan(document.body||document.documentElement);
})();
""".trimIndent()
}
