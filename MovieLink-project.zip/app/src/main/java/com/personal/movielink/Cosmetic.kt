package com.personal.movielink

object Cosmetic {
    // Dummy window so ad scripts think the popup opened and don't fall back to redirecting the page
    private val POPUP_JS = """
window.open=function(){try{window.__popped&&window.__popped();}catch(e){}return {closed:false,focus:function(){},blur:function(){},close:function(){},postMessage:function(){},document:{write:function(){},close:function(){}},location:{href:''}};};
""".trimIndent()

    // Download pages (other sites): many of them "eat" your first tap on the download button with an ad popup
    // and only react on the second tap. If the first tap was eaten by a (blocked) popup and nothing else
    // happened, tap the same button once more automatically.
    private val ASSIST_JS = """
(function(){
  if(window.top!==window||window.__asst)return; window.__asst=1;
  var H='__HOSTS__'.split(','),h=location.hostname;
  for(var i=0;i<H.length;i++){if(h===H[i]||h.endsWith('.'+H[i]))return;}
  var lastPop=0,navd=false;
  window.__popped=function(){lastPop=Date.now();};
  window.addEventListener('beforeunload',function(){navd=true;});
  document.addEventListener('click',function(ev){
    if(!ev.isTrusted||!ev.target||!ev.target.closest)return;
    var el=ev.target.closest('a,button,[role=button],[onclick]');
    if(!el||!/download/i.test(el.textContent||''))return;
    var t0=Date.now();
    setTimeout(function(){
      if(navd||el.__again||!document.contains(el))return;
      if(window.__dl&&window.__dl>=t0)return;
      if(lastPop<t0)return;
      el.__again=1;
      el.click();
    },1100);
  },true);
})();
""".trimIndent().replace("__HOSTS__", Config.INTERNAL_SUFFIXES.joinToString(","))

    // Theme for the movie site (internal pages only; download pages are never touched):
    //  - outermost page background -> #000000 (found by looking at the screen edges)
    //  - boxes -> #0c0c0c (movie page: greys -> #000000)
    //  - saturated colours (red/orange/yellow/green/cyan/blue/purple/pink) in backgrounds, text, borders,
    //    gradients and glows -> a minimal palette of dark greys / soft whites
    // Light pages (e.g. the white download page) are detected and left completely alone.
    private val AMOLED_JS = """
(function(){
  var H='__HOSTS__'.split(','),h=location.hostname,ok=false;
  for(var i=0;i<H.length;i++){if(h===H[i]||h.endsWith('.'+H[i]))ok=true;}
  if(!ok||window.__amo)return; window.__amo=1;
  var off=false,mods=[],ticks=0,boxesOn=false,isMovie=false,lastMv=0;
  function report(l){try{AmoledBridge.light(l);}catch(e){}}
  function info(el){
    var m=getComputedStyle(el).backgroundColor.match(/[\d.]+/g);
    if(!m||m.length<3)return null;
    var a=m.length>3?+m[3]:1;
    if(a<0.5)return null;
    var r=+m[0],g=+m[1],b=+m[2];
    return {lum:0.299*r+0.587*g+0.114*b,neutral:(Math.max(r,g,b)-Math.min(r,g,b))<=48,black:(r+g+b)===0};
  }
  function setProp(el,prop,val){
    var s=el.__pm||(el.__pm={});
    if(!(prop in s))s[prop]=[el.style.getPropertyValue(prop),el.style.getPropertyPriority(prop)];
    el.style.setProperty(prop,val,'important');
    mods.push(el);
  }
  function setBlack(el){setProp(el,'background-color','#000000');}
  function revert(){
    for(var i=0;i<mods.length;i++){
      var e=mods[i],s=e.__pm; if(!s)continue;
      for(var k in s){var v=s[k];if(v[0])e.style.setProperty(k,v[0],v[1]);else e.style.removeProperty(k);}
      e.__pm=null;
    }
    mods=[];
  }
  function check(final){
    if(off||!document.body||!document.elementsFromPoint)return;
    var vw=innerWidth,vh=innerHeight;
    if(!vw||!vh)return;
    var pts=[[1,.25],[1,.5],[1,.75],[vw-2,.25],[vw-2,.5],[vw-2,.75]],cand=[],dark=0,light=0;
    for(var i=0;i<pts.length;i++){
      var stack=document.elementsFromPoint(pts[i][0],vh*pts[i][1]),vis=null;
      for(var j=0;j<stack.length;j++){
        var el=stack[j],page=(el===document.body||el===document.documentElement);
        if(!page){var r=el.getBoundingClientRect();if(r.height<vh*0.9||r.width<vw*0.95)continue;}
        var o=info(el);
        if(!o)continue;
        if(!vis)vis=o;
        if(o.neutral&&o.lum<=110&&!o.black&&cand.indexOf(el)<0)cand.push(el);
      }
      if(vis){if(vis.neutral&&vis.lum<=110)dark++;else if(vis.lum>160)light++;}
    }
    if(light>pts.length/2){off=true;revert();report(true);return;}   // light page: leave it alone
    if(dark>0){report(false);for(var k=0;k<cand.length;k++)setBlack(cand[k]);startBoxes();return;}
    if(final){off=true;revert();report(true);}                        // no dark page background found
  }

  // ---------- colour theme ----------
  var BG=['#1c1c1c','#202020','#262626','#181818','#1e1e1e','#141414','#222222','#1a1a1a'];   // by hue class
  var FG=['#c4c4c4','#d0d0d0','#ececec','#a8a8a8','#dadada','#9e9e9e','#cccccc','#e0e0e0'];
  function rgba(s){var m=s.match(/[\d.]+/g);if(!m||m.length<3)return null;return {r:+m[0],g:+m[1],b:+m[2],a:m.length>3?+m[3]:1};}
  function lumOf(c){return 0.299*c.r+0.587*c.g+0.114*c.b;}
  function satOf(c){return Math.max(c.r,c.g,c.b)-Math.min(c.r,c.g,c.b);}
  function cls(c){
    var mx=Math.max(c.r,c.g,c.b),mn=Math.min(c.r,c.g,c.b),d=mx-mn,hh;
    if(d===0)return 5;
    if(mx===c.r)hh=((c.g-c.b)/d)%6;else if(mx===c.g)hh=(c.b-c.r)/d+2;else hh=(c.r-c.g)/d+4;
    hh*=60;if(hh<0)hh+=360;
    if(hh<15||hh>=345)return 0;   // red
    if(hh<40)return 1;            // orange
    if(hh<70)return 2;            // yellow
    if(hh<165)return 3;           // green
    if(hh<200)return 4;           // cyan / teal
    if(hh<255)return 5;           // blue
    if(hh<290)return 6;           // purple / violet
    return 7;                     // pink / magenta
  }
  // movie page = any inner page that shows the movie details ("Watch Trailer" / "Storyline")
  function movieMode(){
    if(location.pathname==='/'||location.pathname==='')return false;
    if(!isMovie){
      var now=Date.now();
      if(now-lastMv>250&&document.body){
        lastMv=now;
        if(/watch\s*trailer|storyline/i.test(document.body.textContent||'')){isMovie=true;setTimeout(scanAll,0);}
      }
    }
    return isMovie;
  }
  function collect(root,out){
    if(root.nodeType!==1)return;
    out.push(root);
    var d=root.querySelectorAll('*');
    for(var i=0;i<d.length;i++)out.push(d[i]);
  }
  function ancDk(el){
    var p=el.parentElement;
    for(var d=0;p&&d<8;d++,p=p.parentElement){if(p.__dk)return true;}
    return false;
  }
  var SKIP={IMG:1,VIDEO:1,CANVAS:1,SVG:1,svg:1,SCRIPT:1,STYLE:1,HTML:1,BODY:1,IFRAME:1,PATH:1,path:1,NOSCRIPT:1};
  var SIDES=['Top','Right','Bottom','Left'];
  function recolor(list){
    if(off)return;
    var vh=innerHeight,inner=(location.pathname!=='/'&&location.pathname!==''),mv=movieMode(),w=[];
    for(var i=0;i<list.length;i++){
      var el=list[i];
      if(SKIP[el.tagName]||(el.__bx&&!(mv&&el.__bx===1)))continue;
      var rc=el.getBoundingClientRect();
      if(!rc.width||!rc.height)continue;
      el.__bx=mv?2:1;
      var cs=getComputedStyle(el),ch=[],t=null;
      var clipText=(cs.webkitBackgroundClip==='text'||cs.backgroundClip==='text');
      if(!clipText){
        var bg=rgba(cs.backgroundColor);
        if(bg&&bg.a>=0.02){
          var lum=lumOf(bg),sat=satOf(bg),opaque=bg.a>=0.95;
          var big=(rc.height<vh*0.9&&rc.height>=26&&rc.width>=26);
          // inner pages (movie page, categories...): every dark/light grey background -> pure black
          if(mv){
            if(bg.a>=0.6){if((bg.r+bg.g+bg.b)>0)t=(rc.height<10&&sat>=40)?FG[cls(bg)]:'#000000';}
            else if((bg.r+bg.g+bg.b)>0)t='transparent';
          }
          else if(inner&&opaque&&sat<40&&lum<=110&&(bg.r+bg.g+bg.b)>0)t='#000000';
          else if(inner&&!opaque&&sat<40&&lum>=150&&big)t='#000000';
          else if(opaque&&big&&!(bg.r===12&&bg.g===12&&bg.b===12)&&(!inner||sat>=40))t='#0c0c0c';
          else if(bg.a>=0.3&&sat>=40)t=BG[cls(bg)];
        }
        var bi=cs.backgroundImage;
        if(bi&&bi!=='none'&&bi.indexOf('gradient')>=0&&bi.indexOf('url(')<0){
          var re=/rgba?\(([^)]+)\)/g,mm,sg=false,ng=false;
          while((mm=re.exec(bi))){
            var p=mm[1].split(',');
            if(p.length>=3){
              var q={r:+p[0],g:+p[1],b:+p[2],a:p.length>3?+p[3]:1};
              if(q.a>0.3){if(satOf(q)>=40)sg=true;if(q.r+q.g+q.b>0)ng=true;}
            }
          }
          if(sg||(mv&&ng)){ch.push(['background-image','none']);if(!t)t=mv?'#000000':'#141414';}
        }
        if(t){ch.push(['background-color',t]);el.__dk=1;}
        var fc=rgba(cs.color),fs=parseFloat(cs.fontSize)||16;
        if(fc&&fc.a>0.3){
          if(satOf(fc)>=40){if(fs<28)ch.push(['color',FG[cls(fc)]]);}
          else if(lumOf(fc)<150&&(t||ancDk(el)))ch.push(['color','#e6e6e6']);
        }
      }
      for(var s=0;s<4;s++){
        var bw=parseFloat(cs['border'+SIDES[s]+'Width']);
        if(bw>0&&cs['border'+SIDES[s]+'Style']!=='none'){
          var bc=rgba(cs['border'+SIDES[s]+'Color']);
          if(bc&&bc.a>0.3&&satOf(bc)>=40)ch.push(['border-'+SIDES[s].toLowerCase()+'-color','#2e2e2e']);
        }
      }
      var bs=cs.boxShadow;
      if(bs&&bs!=='none'){
        var re2=/rgba?\(([^)]+)\)/g,m2;
        while((m2=re2.exec(bs))){
          var p2=m2[1].split(',');
          if(p2.length>=3){
            var q2={r:+p2[0],g:+p2[1],b:+p2[2],a:p2.length>3?+p2[3]:1};
            if(q2.a>0.3&&satOf(q2)>=40){ch.push(['box-shadow','none']);break;}
          }
        }
      }
      if(ch.length)w.push(el,ch);
    }
    for(var j=0;j<w.length;j+=2){
      var cc=w[j+1];
      for(var k=0;k<cc.length;k++)setProp(w[j],cc[k][0],cc[k][1]);
    }
  }
  function scanAll(){if(off)return;var o=[];collect(document.documentElement,o);recolor(o);}
  function startBoxes(){
    if(boxesOn||off)return;
    boxesOn=true;
    scanAll();
    var q=[],t=0;
    var qa=[];
    new MutationObserver(function(ms){
      if(off)return;
      for(var i=0;i<ms.length;i++){
        var mr=ms[i];
        if(mr.type==='attributes'){if(mr.target.nodeType===1){mr.target.__bx=0;qa.push(mr.target);}}
        else{var nn=mr.addedNodes;for(var j=0;j<nn.length;j++)q.push(nn[j]);}
      }
      if(!t)t=requestAnimationFrame(function(){
        t=0;var o=[],n=q.splice(0),a=qa.splice(0);
        for(var k=0;k<n.length;k++)collect(n[k],o);
        for(var l=0;l<a.length;l++)o.push(a[l]);
        recolor(o);
      });
    }).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});
    setTimeout(scanAll,700);
    setTimeout(scanAll,2000);
  }

  function tick(){if(off)return;check(false);if(++ticks<12)setTimeout(tick,120);}
  tick();
  window.__amoRun=function(){check(false);};
  document.addEventListener('DOMContentLoaded',function(){check(false);});
  window.addEventListener('load',function(){
    check(false);
    setTimeout(function(){check(false);},900);
    setTimeout(function(){check(true);},2500);
  });
})();
""".trimIndent().replace("__HOSTS__", Config.INTERNAL_SUFFIXES.joinToString(","))

    val EARLY_JS = POPUP_JS + "\n" + ASSIST_JS + "\n" + AMOLED_JS

    // Runs after load: hide leftover ad boxes and remove invisible click-hijack overlays.
    // (Generic "ad-" class hiding was removed on purpose: sites use those as bait to detect ad-blockers.)
    val PAGE_JS = """
(function(){
  if(window.__amoRun)window.__amoRun();
  if(window.__abk)return; window.__abk=1;
  var st=document.createElement('style');
  st.textContent='ins.adsbygoogle,[id^="google_ads"],[class*="popunder"],[id*="popunder"],'
   +'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="adsterra"]{display:none!important}';
  (document.head||document.documentElement).appendChild(st);
  function chk(e){
    if(e.nodeType!==1)return;
    var cs=getComputedStyle(e);
    if(cs.position!=='fixed'&&cs.position!=='absolute')return;
    if((parseInt(cs.zIndex)||0)<1000)return;
    var r=e.getBoundingClientRect();
    if(r.width>=innerWidth*0.9&&r.height>=innerHeight*0.9&&e.textContent.trim()===''&&!e.querySelector('video,img,canvas'))e.remove();
  }
  function scan(root){
    chk(root);
    if(root.querySelectorAll){var l=root.querySelectorAll('div,a,span');for(var i=0;i<l.length&&i<300;i++)chk(l[i]);}
  }
  var q=[],t=null;
  new MutationObserver(function(ms){
    for(var i=0;i<ms.length;i++){var n=ms[i].addedNodes;for(var j=0;j<n.length;j++)q.push(n[j]);}
    if(!t)t=setTimeout(function(){t=null;var n=q.splice(0);for(var k=0;k<n.length;k++)scan(n[k]);},300);
  }).observe(document.documentElement,{childList:true,subtree:true});
  scan(document.body||document.documentElement);
})();
""".trimIndent()
}
