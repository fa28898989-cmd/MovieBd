package com.personal.movielink

object Cosmetic {
    // Dummy window so ad scripts think the popup opened and don't fall back to redirecting the page
    private val POPUP_JS = """
window.open=function(){try{window.__popped&&window.__popped();}catch(e){}return {closed:false,focus:function(){},blur:function(){},close:function(){},postMessage:function(){},document:{write:function(){},close:function(){}},location:{href:''}};};
""".trimIndent()

    // Download pages (other sites): many of them "eat" your first tap on the download button with an ad popup
    // and only react on the second tap. If the first tap was eaten by a (blocked) popup and nothing else
    // happened, tap the same button once more automatically.
    private val ASSIST_JS = """
(function(){
  if(window.top!==window||window.__asst)return; window.__asst=1;
  var H='__HOSTS__'.split(','),h=location.hostname;
  for(var i=0;i<H.length;i++){if(h===H[i]||h.endsWith('.'+H[i]))return;}
  var lastPop=0,navd=false;
  window.__popped=function(){lastPop=Date.now();};
  window.addEventListener('beforeunload',function(){navd=true;});
  document.addEventListener('click',function(ev){
    if(!ev.isTrusted||!ev.target||!ev.target.closest)return;
    var el=ev.target.closest('a,button,[role=button],[onclick]');
    if(!el||!/download/i.test(el.textContent||''))return;
    var t0=Date.now();
    setTimeout(function(){
      if(navd||el.__again||!document.contains(el))return;
      if(window.__dl&&window.__dl>=t0)return;
      if(lastPop<t0)return;
      el.__again=1;
      el.click();
    },1100);
  },true);
})();
""".trimIndent().replace("__HOSTS__", Config.INTERNAL_SUFFIXES.joinToString(","))

    // ONLY change: the outermost page background becomes #000000 when it is dark grey.
    // It finds whatever element really paints the page background by looking at the screen edges
    // (html, body or a full-page wrapper). Sections, cards, buttons, text, layout: untouched.
    // Light pages (e.g. download pages) are detected and left completely alone.
    private val AMOLED_JS = """
(function(){
  var H='__HOSTS__'.split(','),h=location.hostname,ok=false;
  for(var i=0;i<H.length;i++){if(h===H[i]||h.endsWith('.'+H[i]))ok=true;}
  if(!ok||window.__amo)return; window.__amo=1;
  var off=false,mods=[],ticks=0;
  function report(l){try{AmoledBridge.light(l);}catch(e){}}
  function info(el){
    var m=getComputedStyle(el).backgroundColor.match(/[\d.]+/g);
    if(!m||m.length<3)return null;
    var a=m.length>3?+m[3]:1;
    if(a<0.5)return null;
    var r=+m[0],g=+m[1],b=+m[2];
    return {lum:0.299*r+0.587*g+0.114*b,neutral:(Math.max(r,g,b)-Math.min(r,g,b))<=48,black:(r+g+b)===0};
  }
  function setBlack(el){
    if(el.__pb===undefined)el.__pb=[el.style.getPropertyValue('background-color'),el.style.getPropertyPriority('background-color')];
    el.style.setProperty('background-color','#000000','important');
    mods.push(el);
  }
  function revert(){
    for(var i=0;i<mods.length;i++){
      var e=mods[i],p=e.__pb;if(!p)continue;
      if(p[0])e.style.setProperty('background-color',p[0],p[1]);else e.style.removeProperty('background-color');
      var q=e.__pbi;
      if(q){if(q[0])e.style.setProperty('background-image',q[0],q[1]);else e.style.removeProperty('background-image');}
    }
    mods=[];
  }
  function check(final){
    if(off||!document.body||!document.elementsFromPoint)return;
    var vw=innerWidth,vh=innerHeight;
    if(!vw||!vh)return;
    var pts=[[1,.25],[1,.5],[1,.75],[vw-2,.25],[vw-2,.5],[vw-2,.75]],cand=[],dark=0,light=0;
    for(var i=0;i<pts.length;i++){
      var stack=document.elementsFromPoint(pts[i][0],vh*pts[i][1]),vis=null;
      for(var j=0;j<stack.length;j++){
        var el=stack[j],page=(el===document.body||el===document.documentElement);
        if(!page){var r=el.getBoundingClientRect();if(r.height<vh*0.9||r.width<vw*0.95)continue;}
        var o=info(el);
        if(!o)continue;
        if(!vis)vis=o;
        if(o.neutral&&o.lum<=110&&!o.black&&cand.indexOf(el)<0)cand.push(el);
      }
      if(vis){if(vis.neutral&&vis.lum<=110)dark++;else if(vis.lum>160)light++;}
    }
    if(light>pts.length/2){off=true;revert();report(true);return;}   // light page: leave it alone
    if(dark>0){report(false);for(var k=0;k<cand.length;k++)setBlack(cand[k]);startBoxes();return;}
    if(final){off=true;revert();report(true);}                        // no dark page background found
  }
  var boxesOn=false;
  function collect(root,out){
    if(root.nodeType!==1)return;
    out.push(root);
    var d=root.querySelectorAll('*');
    for(var i=0;i<d.length;i++)out.push(d[i]);
  }
  function setBox(el,c,noImg){
    if(el.__pb===undefined)el.__pb=[el.style.getPropertyValue('background-color'),el.style.getPropertyPriority('background-color')];
    el.style.setProperty('background-color',c,'important');
    if(noImg){
      if(el.__pbi===undefined)el.__pbi=[el.style.getPropertyValue('background-image'),el.style.getPropertyPriority('background-image')];
      el.style.setProperty('background-image','none','important');
    }
    mods.push(el);
  }
  var SKIP={IMG:1,VIDEO:1,CANVAS:1,SVG:1,svg:1,SCRIPT:1,STYLE:1,HTML:1,BODY:1,IFRAME:1,PATH:1,path:1,NOSCRIPT:1};
  // Home page: solid "boxes" (buttons, cards, notice...) -> #0c0c0c.
  // Other pages (movie page): dark/light grey backgrounds -> #000000. Coloured badges/bars/text stay as they are.
  function recolor(list){
    if(off)return;
    var vh=innerHeight,home=(location.pathname==='/'||location.pathname===''),w=[];
    for(var i=0;i<list.length;i++){
      var el=list[i];
      if(el.__bx||SKIP[el.tagName])continue;
      var cs=getComputedStyle(el),m=cs.backgroundColor.match(/[\d.]+/g);
      if(!m||m.length<3)continue;
      var a=m.length>3?+m[3]:1;
      if(a===0)continue;
      var rc=el.getBoundingClientRect();
      if(!rc.width||!rc.height)continue;
      el.__bx=1;
      if(a<0.95)continue;
      var r=+m[0],g=+m[1],b=+m[2],lum=0.299*r+0.587*g+0.114*b,t=null,ni=false;
      if(home){
        if(rc.height>=vh*0.9||rc.height<26||rc.width<26)continue;
        if(r===12&&g===12&&b===12)continue;
        t='#0c0c0c';
        var bi=cs.backgroundImage;
        ni=!!(bi&&bi.indexOf('gradient')>=0&&bi.indexOf('url(')<0);
      }else{
        if(Math.max(r,g,b)-Math.min(r,g,b)>30||lum>110||(r+g+b)===0)continue;
        t='#000000';
      }
      w.push(el,t,ni);
    }
    for(var j=0;j<w.length;j+=3)setBox(w[j],w[j+1],w[j+2]);
  }
  function scanAll(){if(off)return;var o=[];collect(document.documentElement,o);recolor(o);}
  function startBoxes(){
    if(boxesOn||off)return;
    boxesOn=true;
    scanAll();
    var q=[],t=0;
    new MutationObserver(function(ms){
      if(off)return;
      for(var i=0;i<ms.length;i++){var n=ms[i].addedNodes;for(var j=0;j<n.length;j++)q.push(n[j]);}
      if(!t)t=requestAnimationFrame(function(){
        t=0;var o=[],n=q.splice(0);
        for(var k=0;k<n.length;k++)collect(n[k],o);
        recolor(o);
      });
    }).observe(document.documentElement,{childList:true,subtree:true});
    setTimeout(scanAll,700);
    setTimeout(scanAll,2000);
  }
  function tick(){if(off)return;check(false);if(++ticks<12)setTimeout(tick,120);}
  tick();
  window.__amoRun=function(){check(false);};
  document.addEventListener('DOMContentLoaded',function(){check(false);});
  window.addEventListener('load',function(){
    check(false);
    setTimeout(function(){check(false);},900);
    setTimeout(function(){check(true);},2500);
  });
})();
""".trimIndent().replace("__HOSTS__", Config.INTERNAL_SUFFIXES.joinToString(","))

    val EARLY_JS = POPUP_JS + "\n" + ASSIST_JS + "\n" + AMOLED_JS

    // Runs after load: hide leftover ad boxes and remove invisible click-hijack overlays.
    // (Generic "ad-" class hiding was removed on purpose: sites use those as bait to detect ad-blockers.)
    val PAGE_JS = """
(function(){
  if(window.__amoRun)window.__amoRun();
  if(window.__abk)return; window.__abk=1;
  var st=document.createElement('style');
  st.textContent='ins.adsbygoogle,[id^="google_ads"],[class*="popunder"],[id*="popunder"],'
   +'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="adsterra"]{display:none!important}';
  (document.head||document.documentElement).appendChild(st);
  function chk(e){
    if(e.nodeType!==1)return;
    var cs=getComputedStyle(e);
    if(cs.position!=='fixed'&&cs.position!=='absolute')return;
    if((parseInt(cs.zIndex)||0)<1000)return;
    var r=e.getBoundingClientRect();
    if(r.width>=innerWidth*0.9&&r.height>=innerHeight*0.9&&e.textContent.trim()===''&&!e.querySelector('video,img,canvas'))e.remove();
  }
  function scan(root){
    chk(root);
    if(root.querySelectorAll){var l=root.querySelectorAll('div,a,span');for(var i=0;i<l.length&&i<300;i++)chk(l[i]);}
  }
  var q=[],t=null;
  new MutationObserver(function(ms){
    for(var i=0;i<ms.length;i++){var n=ms[i].addedNodes;for(var j=0;j<n.length;j++)q.push(n[j]);}
    if(!t)t=setTimeout(function(){t=null;var n=q.splice(0);for(var k=0;k<n.length;k++)scan(n[k]);},300);
  }).observe(document.documentElement,{childList:true,subtree:true});
  scan(document.body||document.documentElement);
})();
""".trimIndent()
}
