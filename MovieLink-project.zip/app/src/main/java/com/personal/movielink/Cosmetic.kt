package com.personal.movielink

object Cosmetic {
    // Dummy window so ad scripts think the popup opened and don't fall back to redirecting the page
    private val POPUP_JS = """
window.open=function(){return {closed:false,focus:function(){},blur:function(){},close:function(){},postMessage:function(){},document:{write:function(){},close:function(){}},location:{href:''}};};
""".trimIndent()

    // ONLY change: the outermost page background (html/body, or the single full-page wrapper)
    // becomes #000000 when it is charcoal/dark grey. Sections, cards, buttons, text, layout: untouched.
    // Light pages (e.g. download pages) are left completely alone.
    private val AMOLED_JS = """
(function(){
  var H='__HOSTS__'.split(','),h=location.hostname,ok=false;
  for(var i=0;i<H.length;i++){if(h===H[i]||h.endsWith('.'+H[i]))ok=true;}
  if(!ok||window.__amo)return; window.__amo=1;
  var st=document.createElement('style');
  st.textContent='html,body{background-color:#000000!important}';
  document.documentElement.appendChild(st);
  var off=false,mods=[];
  function report(l){try{AmoledBridge.light(l);}catch(e){}}
  function info(el){
    if(!el)return null;
    var m=getComputedStyle(el).backgroundColor.match(/[\d.]+/g);
    if(!m||m.length<3)return null;
    var a=m.length>3?+m[3]:1;
    if(a<0.5)return null;
    var r=+m[0],g=+m[1],b=+m[2];
    return {lum:0.299*r+0.587*g+0.114*b,neutral:(Math.max(r,g,b)-Math.min(r,g,b))<=48,black:(r+g+b)===0};
  }
  // full-page wrapper(s) directly under body (and one level in for #app/#root style roots)
  function wrappers(){
    var res=[],el=document.body,rootRe=/^(app|root|__next|__nuxt|wrapper|page|layout)$/i;
    for(var d=0;d<2&&el;d++){
      var nx=null,ks=el.children;
      for(var i=0;i<ks.length;i++){
        var k=ks[i],t=k.tagName;
        if(t==='SCRIPT'||t==='STYLE'||t==='LINK'||t==='NOSCRIPT')continue;
        var r=k.getBoundingClientRect();
        if(r.width>=innerWidth*0.98&&r.height>=innerHeight*0.98){nx=k;break;}
      }
      if(!nx)break;
      res.push(nx);
      if(!rootRe.test(nx.id||''))break;
      el=nx;
    }
    return res;
  }
  function setBlack(el){
    if(el.__pb===undefined)el.__pb=[el.style.getPropertyValue('background-color'),el.style.getPropertyPriority('background-color')];
    el.style.setProperty('background-color','#000000','important');
    mods.push(el);
  }
  function revert(){
    for(var i=0;i<mods.length;i++){
      var e=mods[i],p=e.__pb;if(!p)continue;
      if(p[0])e.style.setProperty('background-color',p[0],p[1]);else e.style.removeProperty('background-color');
    }
    mods=[];
  }
  function check(){
    if(off||!document.body)return;
    st.disabled=true;                       // look at the ORIGINAL colours
    var b=info(document.body),hh=info(document.documentElement),ws=wrappers(),wi=[];
    for(var i=0;i<ws.length;i++)wi.push(info(ws[i]));
    st.disabled=false;
    var src=b||hh;
    if(!src){for(var j=0;j<wi.length;j++){if(wi[j]){src=wi[j];break;}}}
    var dark=src&&src.neutral&&src.lum<=110;
    if(!dark){off=true;revert();st.remove();report(true);return;}   // light page: leave it alone
    report(false);
    for(var k=0;k<ws.length;k++){
      var x=wi[k];
      if(x&&x.neutral&&x.lum<=110&&!x.black)setBlack(ws[k]);
    }
  }
  window.__amoRun=function(){check();};
  document.addEventListener('DOMContentLoaded',check);
  window.addEventListener('load',function(){check();setTimeout(check,900);});
})();
""".trimIndent().replace("__HOSTS__", Config.INTERNAL_SUFFIXES.joinToString(","))

    val EARLY_JS = POPUP_JS + "\n" + AMOLED_JS

    // Runs after load: hide leftover ad boxes and remove invisible click-hijack overlays.
    // (Generic "ad-" class hiding was removed on purpose: sites use those as bait to detect ad-blockers.)
    val PAGE_JS = """
(function(){
  if(window.__amoRun)window.__amoRun();
  if(window.__abk)return; window.__abk=1;
  var st=document.createElement('style');
  st.textContent='ins.adsbygoogle,[id^="google_ads"],[class*="popunder"],[id*="popunder"],'
   +'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="adsterra"]{display:none!important}';
  (document.head||document.documentElement).appendChild(st);
  function chk(e){
    if(e.nodeType!==1)return;
    var cs=getComputedStyle(e);
    if(cs.position!=='fixed'&&cs.position!=='absolute')return;
    if((parseInt(cs.zIndex)||0)<1000)return;
    var r=e.getBoundingClientRect();
    if(r.width>=innerWidth*0.9&&r.height>=innerHeight*0.9&&e.textContent.trim()===''&&!e.querySelector('video,img,canvas'))e.remove();
  }
  function scan(root){
    chk(root);
    if(root.querySelectorAll){var l=root.querySelectorAll('div,a,span');for(var i=0;i<l.length&&i<300;i++)chk(l[i]);}
  }
  var q=[],t=null;
  new MutationObserver(function(ms){
    for(var i=0;i<ms.length;i++){var n=ms[i].addedNodes;for(var j=0;j<n.length;j++)q.push(n[j]);}
    if(!t)t=setTimeout(function(){t=null;var n=q.splice(0);for(var k=0;k<n.length;k++)scan(n[k]);},300);
  }).observe(document.documentElement,{childList:true,subtree:true});
  scan(document.body||document.documentElement);
})();
""".trimIndent()
}
