package com.personal.movielink

object Cosmetic {
    // Dummy window so ad scripts think the popup opened and don't fall back to redirecting the page
    private val POPUP_JS = """
window.open=function(){return {closed:false,focus:function(){},blur:function(){},close:function(){},postMessage:function(){},document:{write:function(){},close:function(){}},location:{href:''}};};
""".trimIndent()

    // ONLY change: the outermost page background becomes #000000 when it is dark grey.
    // It finds whatever element really paints the page background by looking at the screen edges
    // (html, body or a full-page wrapper). Sections, cards, buttons, text, layout: untouched.
    // Light pages (e.g. download pages) are detected and left completely alone.
    private val AMOLED_JS = """
(function(){
  var H='__HOSTS__'.split(','),h=location.hostname,ok=false;
  for(var i=0;i<H.length;i++){if(h===H[i]||h.endsWith('.'+H[i]))ok=true;}
  if(!ok||window.__amo)return; window.__amo=1;
  var off=false,mods=[],ticks=0;
  function report(l){try{AmoledBridge.light(l);}catch(e){}}
  function info(el){
    var m=getComputedStyle(el).backgroundColor.match(/[\d.]+/g);
    if(!m||m.length<3)return null;
    var a=m.length>3?+m[3]:1;
    if(a<0.5)return null;
    var r=+m[0],g=+m[1],b=+m[2];
    return {lum:0.299*r+0.587*g+0.114*b,neutral:(Math.max(r,g,b)-Math.min(r,g,b))<=48,black:(r+g+b)===0};
  }
  function setBlack(el){
    if(el.__pb===undefined)el.__pb=[el.style.getPropertyValue('background-color'),el.style.getPropertyPriority('background-color')];
    el.style.setProperty('background-color','#000000','important');
    mods.push(el);
  }
  function revert(){
    for(var i=0;i<mods.length;i++){
      var e=mods[i],p=e.__pb;if(!p)continue;
      if(p[0])e.style.setProperty('background-color',p[0],p[1]);else e.style.removeProperty('background-color');
    }
    mods=[];
  }
  function check(final){
    if(off||!document.body||!document.elementsFromPoint)return;
    var vw=innerWidth,vh=innerHeight;
    if(!vw||!vh)return;
    var pts=[[1,.25],[1,.5],[1,.75],[vw-2,.25],[vw-2,.5],[vw-2,.75]],cand=[],dark=0,light=0;
    for(var i=0;i<pts.length;i++){
      var stack=document.elementsFromPoint(pts[i][0],vh*pts[i][1]),vis=null;
      for(var j=0;j<stack.length;j++){
        var el=stack[j],page=(el===document.body||el===document.documentElement);
        if(!page){var r=el.getBoundingClientRect();if(r.height<vh*0.9||r.width<vw*0.95)continue;}
        var o=info(el);
        if(!o)continue;
        if(!vis)vis=o;
        if(o.neutral&&o.lum<=110&&!o.black&&cand.indexOf(el)<0)cand.push(el);
      }
      if(vis){if(vis.neutral&&vis.lum<=110)dark++;else if(vis.lum>160)light++;}
    }
    if(light>pts.length/2){off=true;revert();report(true);return;}   // light page: leave it alone
    if(dark>0){report(false);for(var k=0;k<cand.length;k++)setBlack(cand[k]);return;}
    if(final){off=true;revert();report(true);}                        // no dark page background found
  }
  function tick(){if(off)return;check(false);if(++ticks<12)setTimeout(tick,120);}
  tick();
  window.__amoRun=function(){check(false);};
  document.addEventListener('DOMContentLoaded',function(){check(false);});
  window.addEventListener('load',function(){
    check(false);
    setTimeout(function(){check(false);},900);
    setTimeout(function(){check(true);},2500);
  });
})();
""".trimIndent().replace("__HOSTS__", Config.INTERNAL_SUFFIXES.joinToString(","))

    val EARLY_JS = POPUP_JS + "\n" + AMOLED_JS

    // Runs after load: hide leftover ad boxes and remove invisible click-hijack overlays.
    // (Generic "ad-" class hiding was removed on purpose: sites use those as bait to detect ad-blockers.)
    val PAGE_JS = """
(function(){
  if(window.__amoRun)window.__amoRun();
  if(window.__abk)return; window.__abk=1;
  var st=document.createElement('style');
  st.textContent='ins.adsbygoogle,[id^="google_ads"],[class*="popunder"],[id*="popunder"],'
   +'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="adsterra"]{display:none!important}';
  (document.head||document.documentElement).appendChild(st);
  function chk(e){
    if(e.nodeType!==1)return;
    var cs=getComputedStyle(e);
    if(cs.position!=='fixed'&&cs.position!=='absolute')return;
    if((parseInt(cs.zIndex)||0)<1000)return;
    var r=e.getBoundingClientRect();
    if(r.width>=innerWidth*0.9&&r.height>=innerHeight*0.9&&e.textContent.trim()===''&&!e.querySelector('video,img,canvas'))e.remove();
  }
  function scan(root){
    chk(root);
    if(root.querySelectorAll){var l=root.querySelectorAll('div,a,span');for(var i=0;i<l.length&&i<300;i++)chk(l[i]);}
  }
  var q=[],t=null;
  new MutationObserver(function(ms){
    for(var i=0;i<ms.length;i++){var n=ms[i].addedNodes;for(var j=0;j<n.length;j++)q.push(n[j]);}
    if(!t)t=setTimeout(function(){t=null;var n=q.splice(0);for(var k=0;k<n.length;k++)scan(n[k]);},300);
  }).observe(document.documentElement,{childList:true,subtree:true});
  scan(document.body||document.documentElement);
})();
""".trimIndent()
}
