package com.personal.movielink

object Cosmetic {
    // Dummy window so ad scripts think the popup opened and don't fall back to redirecting the page
    private val POPUP_JS = """
window.open=function(){return {closed:false,focus:function(){},blur:function(){},close:function(){},postMessage:function(){},document:{write:function(){},close:function(){}},location:{href:''}};};
""".trimIndent()

    // AMOLED theme for the movie site: page background -> pure #000000; cards, bars and other dark surfaces -> #0d0d0d; bright colours -> toned down.
    // Only touches neutral dark backgrounds (badges, buttons, images keep their colours).
    // Light pages (download pages) are detected and left completely untouched.
    private val AMOLED_JS = """
(function(){
  var H='__HOSTS__'.split(','),h=location.hostname,ok=false;
  for(var i=0;i<H.length;i++){if(h===H[i]||h.endsWith('.'+H[i]))ok=true;}
  if(!ok||window.__amo)return; window.__amo=1;
  var C=['#000000','#0d0d0d','#0d0d0d','#0d0d0d'];
  var PL=/player|plyr|jwplayer|jw-|vjs|embed/i;
  var st=document.createElement('style');
  st.textContent='html,body{background:#000!important}video{background:#000!important}'
    +':fullscreen{background:#000!important}:-webkit-full-screen{background:#000!important}';
  document.documentElement.appendChild(st);
  var off=false,mods=[];
  function report(l){try{AmoledBridge.light(l);}catch(e){}}
  function setBg(el,c){
    if(el.__pb===undefined)el.__pb=[el.style.getPropertyValue('background-color'),el.style.getPropertyPriority('background-color')];
    el.style.setProperty('background-color',c,'important');
    mods.push(el);
  }
  function revert(keep){
    for(var i=0;i<mods.length;i++){
      var e=mods[i],p=e.__pb; if(!p)continue;
      if(keep&&e.__lv===0)continue;
      if(p[0])e.style.setProperty('background-color',p[0],p[1]); else e.style.removeProperty('background-color');
    }
    mods=[];
  }
  function tone(r,g,b){
    r/=255;g/=255;b/=255;
    var mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2,s=0,h=0,d=mx-mn;
    if(d){
      s=l>0.5?d/(2-mx-mn):d/(mx+mn);
      if(mx===r)h=(g-b)/d+(g<b?6:0);else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;
      h/=6;
    }
    s=Math.min(s,0.5);l=Math.min(Math.max(l,0.15),0.3);
    function f(p,q,t){if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return p+(q-p)*6*t;if(t<1/2)return q;if(t<2/3)return p+(q-p)*(2/3-t)*6;return p;}
    var q=l<0.5?l*(1+s):l+s-l*s,p=2*l-q;
    return 'rgb('+Math.round(f(p,q,h+1/3)*255)+','+Math.round(f(p,q,h)*255)+','+Math.round(f(p,q,h-1/3)*255)+')';
  }
  function up(el){var p=el.parentElement;while(p){if(p.__lv!==undefined)return p.__lv;p=p.parentElement;}return -1;}
  function decide(el){
    if(el.__pl===undefined){
      var pp=el.parentElement;
      el.__pl=!!((pp&&pp.__pl)||el.tagName==='VIDEO'||el.tagName==='IFRAME'||PL.test((el.getAttribute('class')||'')+' '+(el.id||'')));
    }
    if(el.__done)return null;
    if(el===document.body||el===document.documentElement){el.__lv=0;el.__done=1;return null;}
    var cs=getComputedStyle(el),m=cs.backgroundColor.match(/[\d.]+/g);
    if(!m||m.length<3)return null;
    var a=m.length>3?+m[3]:1;
    if(a===0)return null;
    el.__done=1;
    var r=+m[0],g=+m[1],b=+m[2];
    el.__ob=[r,g,b,a];
    if(a<0.95)return null;
    var lum=0.299*r+0.587*g+0.114*b;
    var sat=Math.max(r,g,b)-Math.min(r,g,b);
    if(sat>48||lum>110){
      // saturated medium colours (coloured buttons/badges) -> calmer, darker version that suits pure black.
      // Light surfaces, light neutrals and very bright colours (dark text on them) are left alone.
      if(!el.__pl&&sat>48&&lum<=150)return tone(r,g,b);
      return null;
    }
    var l;
    if(el.__pl){l=0;}
    else{
      var rc=el.getBoundingClientRect(),pl=up(el);
      if(rc.width>=innerWidth*0.95&&(rc.height>=innerHeight*0.5||lum<20))l=0;
      else if(pl<0)l=1;
      else l=Math.min(pl+1,3);
      if((cs.position==='fixed'||cs.position==='sticky')&&rc.top<=1)l=0;
    }
    el.__lv=l;
    return C[l];
  }
  function fixVideos(){
    var vs=document.querySelectorAll('video'),w=[];
    for(var i=0;i<vs.length;i++){
      var p=vs[i].parentElement;
      while(p&&p!==document.body&&p!==document.documentElement){
        if(!p.__vb){
          p.__vb=1;
          var m=getComputedStyle(p).backgroundColor.match(/[\d.]+/g);
          if(m&&m.length>=3){
            var a=m.length>3?+m[3]:1,r=+m[0],g=+m[1],b=+m[2];
            if(a>=0.95&&(r+g+b)>0&&Math.max(r,g,b)-Math.min(r,g,b)<=48&&0.299*r+0.587*g+0.114*b<=110)w.push(p);
          }
        }
        p=p.parentElement;
      }
    }
    for(var j=0;j<w.length;j++)setBg(w[j],'#000000');
  }
  // Finds whatever is really painting the page's gray at the left/right edges (where cards don't reach)
  // and turns that layer pure black. Works even when the gray is on a wrapper or a gradient.
  function mainBg(){
    var xs=[.01,.99],ys=[.12,.3,.5,.7,.9];
    for(var a=0;a<xs.length;a++)for(var b=0;b<ys.length;b++){
      var els=document.elementsFromPoint(innerWidth*xs[a],innerHeight*ys[b]);
      for(var k=0;k<els.length;k++){
        var e=els[k],tn=e.tagName;
        if(tn==='VIDEO'||tn==='IFRAME'||tn==='CANVAS'||tn==='IMG')break;
        if(e.__mb)continue;
        var rc=e.getBoundingClientRect();
        if(rc.width<innerWidth*0.9)continue;
        var cs=getComputedStyle(e),m=cs.backgroundColor.match(/[\d.]+/g),al=0,r=0,g=0,bl=0;
        if(m&&m.length>=3){r=+m[0];g=+m[1];bl=+m[2];al=m.length>3?+m[3]:1;}
        var dark=al>=0.5&&Math.max(r,g,bl)-Math.min(r,g,bl)<=48&&(0.299*r+0.587*g+0.114*bl)<=110;
        var grad=cs.backgroundImage&&cs.backgroundImage!=='none'&&rc.height>=innerHeight*0.6;
        if(dark||grad){
          e.__mb=1;e.__lv=0;
          setBg(e,'#000000');
          if(grad)e.style.setProperty('background-image','none','important');
        }
      }
    }
  }
  function run(list){
    if(off)return;
    var w=[];
    for(var i=0;i<list.length;i++){var c=decide(list[i]);if(c)w.push(list[i],c);}
    for(var j=0;j<w.length;j+=2)setBg(w[j],w[j+1]);
    fixVideos();
  }
  function collect(root,out){
    if(root.nodeType!==1)return;
    out.push(root);
    var d=root.querySelectorAll('*');
    for(var i=0;i<d.length;i++)out.push(d[i]);
  }
  function all(){var o=[];collect(document.documentElement,o);run(o);mainBg();}
  function origRgb(el){
    var o=el.__ob;
    if(!o){
      var m=getComputedStyle(el).backgroundColor.match(/[\d.]+/g);
      if(!m||m.length<3)return null;
      o=[+m[0],+m[1],+m[2],m.length>3?+m[3]:1];
    }
    return o;
  }
  function pageLum(){
    var es=[document.body,document.documentElement];
    for(var i=0;i<es.length;i++){
      if(!es[i])continue;
      var m=getComputedStyle(es[i]).backgroundColor.match(/[\d.]+/g);
      if(m&&m.length>=3){var a=m.length>3?+m[3]:1;if(a>=0.5)return 0.299*+m[0]+0.587*+m[1]+0.114*+m[2];}
    }
    return 255;
  }
  function pageDark(){
    var es=[document.body,document.documentElement];
    for(var i=0;i<es.length;i++){
      if(!es[i])continue;
      var m=getComputedStyle(es[i]).backgroundColor.match(/[\d.]+/g);
      if(m&&m.length>=3){
        var a=m.length>3?+m[3]:1;
        if(a>=0.5){var r=+m[0],g=+m[1],b=+m[2];return Math.max(r,g,b)-Math.min(r,g,b)<=48&&0.299*r+0.587*g+0.114*b<=110;}
      }
    }
    return false;
  }
  // Light page (e.g. download page)? undo everything except the main dark background (kept pure black)
  function check(){
    if(off)return;
    st.disabled=true;
    var pg=pageLum(),pd=pageDark(),pts=[[.5,.2],[.5,.5],[.5,.8],[.2,.5],[.8,.5]],light=0;
    for(var i=0;i<pts.length;i++){
      var el=document.elementFromPoint(innerWidth*pts[i][0],innerHeight*pts[i][1]),v=-1;
      while(el&&el!==document.body&&el!==document.documentElement){
        var o=origRgb(el);
        if(o&&o[3]>=0.5){v=0.299*o[0]+0.587*o[1]+0.114*o[2];break;}
        el=el.parentElement;
      }
      if(v<0)v=pg;
      if(v>160)light++;
    }
    st.disabled=false;
    if(light>=3){off=true;if(pd){revert(true);}else{revert(false);st.remove();}report(true);}
    else report(false);
  }
  window.__amoRun=function(){if(!off)all();};
  var q=[],t=0;
  new MutationObserver(function(ms){
    if(off)return;
    for(var i=0;i<ms.length;i++){var n=ms[i].addedNodes;for(var j=0;j<n.length;j++)q.push(n[j]);}
    if(!t)t=requestAnimationFrame(function(){
      t=0;var o=[],n=q.splice(0);
      for(var k=0;k<n.length;k++)collect(n[k],o);
      run(o);
    });
  }).observe(document.documentElement,{childList:true,subtree:true});
  function fs(){if(!off)fixVideos();}
  document.addEventListener('fullscreenchange',fs);
  document.addEventListener('webkitfullscreenchange',fs);
  window.addEventListener('load',function(){
    all();setTimeout(check,50);
    setTimeout(function(){all();check();},900);
    setTimeout(function(){if(!off)mainBg();},2000);
    setTimeout(function(){if(!off)mainBg();},4500);
  });
})();
""".trimIndent().replace("__HOSTS__", Config.INTERNAL_SUFFIXES.joinToString(","))


    // Removes the site's "Ad-blocker detected" popup (and its dark backdrop) and keeps the page scrollable.
    // Light on purpose: only newly added fixed-position boxes are checked, plus a few timed scans at startup.
    private val NOPOPUP_JS = """
(function(){
  var H='__HOSTS__'.split(','),h=location.hostname,ok=false;
  for(var i=0;i<H.length;i++){if(h===H[i]||h.endsWith('.'+H[i]))ok=true;}
  if(!ok||window.__nab)return; window.__nab=1;
  var RX=/ad[\s\-_]?block/i,t0=Date.now();
  var CAND='[role="dialog"],dialog,[class*="modal" i],[class*="popup" i],[class*="adb" i],[id*="modal" i],[id*="popup" i],[id*="adb" i],[id*="block" i]';
  function overlayOf(el){
    var top=null,p=el;
    while(p&&p!==document.body&&p!==document.documentElement){
      if(getComputedStyle(p).position==='fixed')top=p;
      p=p.parentElement;
    }
    if(!top){var cs=getComputedStyle(el);if(cs.position==='absolute'&&(parseInt(cs.zIndex)||0)>=100)top=el;}
    return top;
  }
  function unlock(){
    var es=[document.body,document.documentElement];
    for(var i=0;i<es.length;i++){
      var e=es[i]; if(!e)continue;
      if(e.style.overflow==='hidden')e.style.removeProperty('overflow');
      if(e.style.overflowY==='hidden')e.style.removeProperty('overflow-y');
      var c=(e.getAttribute('class')||'').split(/\s+/);
      for(var j=0;j<c.length;j++){if(c[j]&&/modal|lock|no-?scroll|overflow/i.test(c[j]))e.classList.remove(c[j]);}
    }
  }
  function kill(o){
    if(o.__nab)return; o.__nab=1;
    try{
      var bs=o.querySelectorAll('button,[role="button"],input[type="button"]'),b=null;
      for(var i=0;i<bs.length;i++){if(/বুঝলাম|ok|got it|close|dismiss|continue/i.test(bs[i].textContent||bs[i].value||'')){b=bs[i];break;}}
      if(!b&&bs.length)b=bs[0];
      if(b)b.click();
    }catch(e){}
    o.style.setProperty('display','none','important');
    var sb=[o.previousElementSibling,o.nextElementSibling];
    for(var k=0;k<2;k++){
      var s=sb[k]; if(!s||s.__nab)continue;
      var cs=getComputedStyle(s);
      if(cs.position==='fixed'&&s.textContent.trim()===''&&s.getBoundingClientRect().width>=innerWidth*0.9){
        s.__nab=1;s.style.setProperty('display','none','important');
      }
    }
    unlock();
  }
  function chk(c){
    if(c.__nab)return;
    var tx=c.textContent;
    if(!tx||tx.length>1500||!RX.test(tx))return;
    var o=overlayOf(c);
    if(o)kill(o);
  }
  function scan(){
    var l;
    try{l=document.querySelectorAll(CAND);}catch(e){return;}
    for(var i=0;i<l.length&&i<150;i++)chk(l[i]);
  }
  var q=[],t=0;
  new MutationObserver(function(ms){
    if(Date.now()-t0>12000)return;
    for(var i=0;i<ms.length;i++){
      var n=ms[i].addedNodes;
      for(var j=0;j<n.length;j++){if(n[j].nodeType===1&&q.length<40)q.push(n[j]);}
    }
    if(q.length&&!t)t=requestAnimationFrame(function(){
      t=0;var n=q.splice(0);
      for(var k=0;k<n.length;k++){var e=n[k];if(e.isConnected&&getComputedStyle(e).position==='fixed')chk(e);}
    });
  }).observe(document.documentElement,{childList:true,subtree:true});
  document.addEventListener('DOMContentLoaded',scan);
  window.addEventListener('load',function(){scan();setTimeout(scan,600);setTimeout(scan,1800);setTimeout(scan,3500);setTimeout(scan,6000);});
})();
""".trimIndent().replace("__HOSTS__", Config.INTERNAL_SUFFIXES.joinToString(","))

    // Used by the "Open in Chrome" / "Open in IDM" buttons on the download screen
    val FIND_LINK_JS = """
(function(){
  function ok(h){return h&&/^https?:/i.test(h)&&h.split('#')[0]!==location.href.split('#')[0];}
  var l=document.querySelectorAll('a[href],[data-href],[data-url],[data-link]');
  for(var i=0;i<l.length;i++){
    var e=l[i],t=(e.textContent||'').toLowerCase();
    if(!/download\s*now/.test(t))continue;
    var h=(typeof e.href==='string'&&e.href)?e.href:(e.getAttribute('data-href')||e.getAttribute('data-url')||e.getAttribute('data-link')||'');
    if(ok(h))return h;
  }
  return '';
})()
""".trimIndent()

    val CLICK_DL_JS = """
(function(){
  var l=document.querySelectorAll('a,button,[role="button"]'),b=null,b2=null;
  for(var i=0;i<l.length;i++){
    var t=(l[i].textContent||'').toLowerCase();
    if(!b&&/download\s*now/.test(t))b=l[i];
    if(!b2&&/download/.test(t))b2=l[i];
  }
  b=b||b2; if(!b)return false;
  b.click(); return true;
})()
""".trimIndent()

    val EARLY_JS = POPUP_JS + "\n" + AMOLED_JS + "\n" + NOPOPUP_JS

    // Runs after load: hide leftover ad boxes and remove invisible click-hijack overlays.
    // Only checks newly added elements, so it stays light.
    val PAGE_JS = """
(function(){
  if(window.__amoRun)window.__amoRun();
  if(window.__abk)return; window.__abk=1;
  var st=document.createElement('style');
  // NOTE: do not hide .adsbox / .ad-banner / div[class^=ad-] here: sites use those as bait to detect ad blockers.
  st.textContent='[class*="popunder"],[id*="popunder"],'
   +'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="adsterra"]{display:none!important}';
  (document.head||document.documentElement).appendChild(st);
  function chk(e){
    if(e.nodeType!==1)return;
    var cs=getComputedStyle(e);
    if(cs.position!=='fixed'&&cs.position!=='absolute')return;
    if((parseInt(cs.zIndex)||0)<1000)return;
    var r=e.getBoundingClientRect();
    if(r.width>=innerWidth*0.9&&r.height>=innerHeight*0.9&&e.textContent.trim()===''&&!e.querySelector('video,img,canvas'))e.remove();
  }
  function scan(root){
    chk(root);
    if(root.querySelectorAll){var l=root.querySelectorAll('div,a,span');for(var i=0;i<l.length&&i<300;i++)chk(l[i]);}
  }
  var q=[],t=null;
  new MutationObserver(function(ms){
    for(var i=0;i<ms.length;i++){var n=ms[i].addedNodes;for(var j=0;j<n.length;j++)q.push(n[j]);}
    if(!t)t=setTimeout(function(){t=null;var n=q.splice(0);for(var k=0;k<n.length;k++)scan(n[k]);},300);
  }).observe(document.documentElement,{childList:true,subtree:true});
  scan(document.body||document.documentElement);
})();
""".trimIndent()
}
