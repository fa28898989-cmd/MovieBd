package com.personal.movielink

object Cosmetic {
    // Dummy window so ad scripts think the popup opened and don't fall back to redirecting the page
    private val POPUP_JS = """
window.open=function(){return {closed:false,focus:function(){},blur:function(){},close:function(){},postMessage:function(){},document:{write:function(){},close:function(){}},location:{href:''}};};
""".trimIndent()

    // AMOLED theme for the movie site: page -> pure black, cards/panels -> subtle dark layers.
    // Only touches neutral dark backgrounds, so coloured badges/buttons/images stay as they are.
    private val AMOLED_JS = """
(function(){
  var H='__HOSTS__'.split(','),h=location.hostname,ok=false;
  for(var i=0;i<H.length;i++){if(h===H[i]||h.endsWith('.'+H[i]))ok=true;}
  if(!ok||window.__amo)return; window.__amo=1;
  var C=['#000000','#0e0e0e','#171717','#202020'];
  var st=document.createElement('style');
  st.textContent='html,body{background:#000!important}';
  document.documentElement.appendChild(st);
  function up(el){var p=el.parentElement;while(p){if(p.__lv!==undefined)return p.__lv;p=p.parentElement;}return -1;}
  function decide(el){
    if(el.__done)return null;
    var cs=getComputedStyle(el),m=cs.backgroundColor.match(/[\d.]+/g);
    if(!m||m.length<3)return null;
    var a=m.length>3?+m[3]:1;
    if(a===0)return null;
    el.__done=1;
    if(a<0.95)return null;
    var r=+m[0],g=+m[1],b=+m[2];
    if(Math.max(r,g,b)-Math.min(r,g,b)>48||0.299*r+0.587*g+0.114*b>110)return null;
    var pl=up(el),l;
    if(pl<0){
      var rc=el.getBoundingClientRect();
      l=(rc.width>=innerWidth*0.98&&rc.height>=innerHeight*0.9)?0:1;
    }else l=Math.min(pl+1,3);
    if((cs.position==='fixed'||cs.position==='sticky')&&el.getBoundingClientRect().top<=1)l=0;
    el.__lv=l;
    return C[l];
  }
  function run(list){
    var w=[];
    for(var i=0;i<list.length;i++){var c=decide(list[i]);if(c)w.push(list[i],c);}
    for(var j=0;j<w.length;j+=2)w[j].style.setProperty('background-color',w[j+1],'important');
  }
  function collect(root,out){
    if(root.nodeType!==1)return;
    out.push(root);
    var d=root.querySelectorAll('*');
    for(var i=0;i<d.length;i++)out.push(d[i]);
  }
  function all(){var o=[];collect(document.documentElement,o);run(o);}
  window.__amoRun=all;
  var q=[],t=0;
  new MutationObserver(function(ms){
    for(var i=0;i<ms.length;i++){var n=ms[i].addedNodes;for(var j=0;j<n.length;j++)q.push(n[j]);}
    if(!t)t=requestAnimationFrame(function(){
      t=0;var o=[],n=q.splice(0);
      for(var k=0;k<n.length;k++)collect(n[k],o);
      run(o);
    });
  }).observe(document.documentElement,{childList:true,subtree:true});
  window.addEventListener('load',function(){all();setTimeout(all,800);});
})();
""".trimIndent().replace("__HOSTS__", Config.INTERNAL_SUFFIXES.joinToString(","))

    val EARLY_JS = POPUP_JS + "\n" + AMOLED_JS

    // Runs after load: hide leftover ad boxes and remove invisible click-hijack overlays.
    // Only checks newly added elements, so it stays light.
    val PAGE_JS = """
(function(){
  if(window.__amoRun)window.__amoRun();
  if(window.__abk)return; window.__abk=1;
  var st=document.createElement('style');
  st.textContent='ins.adsbygoogle,[id^="google_ads"],[class*="popunder"],[id*="popunder"],'
   +'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="adsterra"],'
   +'div[id^="ad-"],div[class^="ad-"],.ad-banner,.ads-banner,.adsbox{display:none!important}';
  (document.head||document.documentElement).appendChild(st);
  function chk(e){
    if(e.nodeType!==1)return;
    var cs=getComputedStyle(e);
    if(cs.position!=='fixed'&&cs.position!=='absolute')return;
    if((parseInt(cs.zIndex)||0)<1000)return;
    var r=e.getBoundingClientRect();
    if(r.width>=innerWidth*0.9&&r.height>=innerHeight*0.9&&e.textContent.trim()===''&&!e.querySelector('video,img,canvas'))e.remove();
  }
  function scan(root){
    chk(root);
    if(root.querySelectorAll){var l=root.querySelectorAll('div,a,span');for(var i=0;i<l.length&&i<300;i++)chk(l[i]);}
  }
  var q=[],t=null;
  new MutationObserver(function(ms){
    for(var i=0;i<ms.length;i++){var n=ms[i].addedNodes;for(var j=0;j<n.length;j++)q.push(n[j]);}
    if(!t)t=setTimeout(function(){t=null;var n=q.splice(0);for(var k=0;k<n.length;k++)scan(n[k]);},300);
  }).observe(document.documentElement,{childList:true,subtree:true});
  scan(document.body||document.documentElement);
})();
""".trimIndent()
}
