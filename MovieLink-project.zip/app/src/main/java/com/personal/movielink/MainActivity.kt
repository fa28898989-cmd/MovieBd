package com.personal.movielink

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var root: FrameLayout
    private lateinit var actionBar: LinearLayout
    private lateinit var progress: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private val resetAlpha = Runnable { web.alpha = 1f }
    @Volatile private var downloadPage = false   // light/download page: no loading effects
    private var loadingInternal = true
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    private val accent = Color.parseColor("#2E9E6B")
    private var downloader: String? = null      // installed IDM / 1DM package, looked up once
    private enum class Want { NONE, CHROME, IDM }
    private var want = Want.NONE
    private var wantUntil = 0L
    private fun wantActive() = want != Want.NONE && System.currentTimeMillis() < wantUntil
    private var startScript = false
    private var lastHandOff = ""
    private var lastHandOffAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        downloader = findDownloader()
        WindowCompat.setDecorFitsSystemWindows(window, true)

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        web = WebView(this).apply { setBackgroundColor(Color.BLACK) }
        refresh = SwipeRefreshLayout(this).apply {
            addView(web)
            setProgressBackgroundColorSchemeColor(Color.BLACK)
            setColorSchemeColors(accent)
        }
        root.addView(refresh, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
            progressTintList = ColorStateList.valueOf(accent)
            progressBackgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        }
        root.addView(progress, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3), Gravity.TOP))

        fun pill(label: String, onTap: () -> Unit) = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0D0D0D"))
                setStroke(dp(1), Color.parseColor("#262626"))
                cornerRadius = dp(22).toFloat()
            }
            setPadding(dp(18), dp(11), dp(18), dp(11))
            setOnClickListener { onTap() }
        }
        actionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            addView(pill("Open in Chrome") { openDownloadIn(chrome = true) })
            addView(
                pill("Open in IDM") { openDownloadIn(chrome = false) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { marginStart = dp(10) }
            )
        }
        root.addView(actionBar, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply { setMargins(0, 0, 0, dp(24)) })
        setContentView(root)

        refresh.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        refresh.setOnRefreshListener {
            val u = web.url
            if (u.isNullOrEmpty() || u.startsWith("data:") || u == "about:blank") web.loadUrl(Config.HOME_URL)
            else web.reload()
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString.replace("; wv", "")
        }
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        web.addJavascriptInterface(Bridge(), "AmoledBridge")
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

        startScript = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        if (startScript) {
            WebViewCompat.addDocumentStartJavaScript(web, Cosmetic.EARLY_JS, setOf("*"))
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return if (AdBlocker.shouldBlock(request.url))
                    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme
                if (scheme != "http" && scheme != "https") return true      // block intent://, market:// etc.
                if (AdBlocker.shouldBlock(uri)) return true
                if (!request.isForMainFrame) return false
                if (Config.isInternal(uri.host)) { navStarting(uri); return false }
                if (wantActive()) { handOff(uri.toString(), view.settings.userAgentString, null, null); return true }
                // Direct file link on a download host: send it to IDM right now instead of waiting
                // for the server's response headers (this is what made IDM open slowly).
                if (Config.isFileUrl(uri)) {
                    val isApk = uri.path?.endsWith(".apk", ignoreCase = true) == true
                    val onDownloadPage = !Config.isInternal(view.url?.let { Uri.parse(it).host })
                    if (request.hasGesture() || request.isRedirect || (onDownloadPage && !isApk)) {
                        handOff(uri.toString(), view.settings.userAgentString, null, null)
                        return true
                    }
                }
                // Other sites (download/file hosts) load INSIDE the app, but only after a real tap
                // or a server redirect. Scripted ad redirects (no tap) are blocked.
                return !(request.hasGesture() || request.isRedirect)
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                loadingInternal = Config.isInternal(url?.let { Uri.parse(it).host })
                downloadPage = false
                updateChromeBtn(url)
                if (!startScript) view.evaluateJavascript(Cosmetic.EARLY_JS, null)
            }

            override fun onPageCommitVisible(view: WebView, url: String?) { showWeb() }

            override fun onPageFinished(view: WebView, url: String?) {
                refresh.isRefreshing = false
                updateChromeBtn(url)
                showWeb()
                if (!startScript) view.evaluateJavascript(Cosmetic.EARLY_JS, null)
                view.evaluateJavascript(Cosmetic.PAGE_JS, null)
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    refresh.isRefreshing = false
                    showWeb()
                    view.loadData(
                        "<body style='background:#000;color:#ccc;font-family:sans-serif;text-align:center;padding-top:30vh'>" +
                            "<h2>Can't load the site</h2><p>Check your connection, then pull down to retry.</p></body>",
                        "text/html", "utf-8"
                    )
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(v: WebView, d: Boolean, g: Boolean, m: android.os.Message?) = false

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                val show = loadingInternal && !downloadPage && newProgress in 1..99
                progress.visibility = if (show) View.VISIBLE else View.GONE
            }

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view; customCb = cb
                view.setBackgroundColor(Color.BLACK)
                refresh.visibility = View.GONE
                root.addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                immersive(true)
            }

            override fun onHideCustomView() { exitFullscreen() }
        }

        web.setDownloadListener { url, ua, cd, mime, _ -> handOff(url, ua, cd, mime) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> exitFullscreen()
                    web.canGoBack() -> web.goBack()
                    else -> finish()
                }
            }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl(Config.HOME_URL)
    }

    // The two buttons on the download screen: take the real download link from the page and open it
    private fun openDownloadIn(chrome: Boolean) {
        web.evaluateJavascript(Cosmetic.FIND_LINK_JS) { raw ->
            val link = try { (org.json.JSONTokener(raw).nextValue() as? String).orEmpty() } catch (_: Exception) { "" }
            if (link.startsWith("http")) {
                if (chrome) openExternal(Uri.parse(link), chrome = true)
                else handOff(link, web.settings.userAgentString, null, null)
            } else {
                // Script-driven button: press it and catch where it sends us
                want = if (chrome) Want.CHROME else Want.IDM
                wantUntil = System.currentTimeMillis() + 8000
                web.evaluateJavascript(Cosmetic.CLICK_DL_JS) { ok ->
                    if (ok != "true") {
                        want = Want.NONE
                        if (chrome) web.url?.let { openExternal(Uri.parse(it), chrome = true) }
                        else Toast.makeText(this, "Download link not found on this page", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun findDownloader(): String? = Config.DOWNLOAD_APPS.firstOrNull { pkg ->
        try { packageManager.getPackageInfo(pkg, 0); true } catch (_: Exception) { false }
    }

    // Single place that sends a file to IDM (with the page's cookies / referer so it can start at once),
    // or to Android's built-in downloader if no download app is installed.
    private fun handOff(url: String, ua: String?, cd: String?, mime: String?) {
        if (wantActive()) {
            val w = want; want = Want.NONE
            if (w == Want.CHROME) { openExternal(Uri.parse(url), chrome = true); return }
        }
        val now = System.currentTimeMillis()
        if (url == lastHandOff && now - lastHandOffAt < 2500) return   // ignore double triggers
        lastHandOff = url; lastHandOffAt = now
        progress.visibility = View.GONE   // a download isn't a page load: clear any loading effect
        showWeb()
        val uri = Uri.parse(url)
        val agent = ua ?: web.settings.userAgentString
        val referer = web.url ?: Config.HOME_URL
        val cookie = CookieManager.getInstance().getCookie(url)

        val pkg = downloader ?: findDownloader().also { downloader = it }
        if (pkg != null) {
            try {
                val headers = Bundle().apply {
                    if (!cookie.isNullOrEmpty()) putString("Cookie", cookie)
                    putString("User-Agent", agent)
                    putString("Referer", referer)
                }
                startActivity(
                    Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)
                        .putExtra("com.android.browser.headers", headers)
                )
                @Suppress("DEPRECATION")
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                return
            } catch (_: Exception) {
                downloader = null
            }
        }
        try {
            val req = DownloadManager.Request(uri)
            if (mime != null) req.setMimeType(mime)
            req.addRequestHeader("Cookie", cookie ?: "")
            req.addRequestHeader("User-Agent", agent)
            req.addRequestHeader("Referer", referer)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime))
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(this, "Downloading…", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            openExternal(uri)
        }
    }

    // Instant tap feedback: dim the old page and show the progress bar right away
    private fun navStarting(target: Uri) {
        // No loading effects on download pages / when heading to download links
        if (downloadPage || target.toString().contains("download", ignoreCase = true)) return
        web.alpha = 0.35f
        progress.progress = 5
        progress.visibility = View.VISIBLE
        handler.removeCallbacks(resetAlpha)
        handler.postDelayed(resetAlpha, 3000)   // safety: never stay dimmed
    }

    // New page painted: fade it in smoothly
    private fun showWeb() {
        handler.removeCallbacks(resetAlpha)
        web.animate().cancel()
        web.animate().alpha(1f).setDuration(140).start()
    }

    inner class Bridge {
        @JavascriptInterface
        fun light(isLight: Boolean) {
            runOnUiThread {
                downloadPage = isLight
                if (isLight) { progress.visibility = View.GONE; showWeb() }
            }
        }
    }

    private fun exitFullscreen() {
        customView?.let { root.removeView(it) }
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        refresh.visibility = View.VISIBLE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        immersive(false)
    }

    private fun immersive(on: Boolean) {
        val c = WindowInsetsControllerCompat(window, root)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (on) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // Shows the "Open in Chrome" button only while you're on a page outside the movie site (e.g. download pages)
    private fun updateChromeBtn(url: String?) {
        val u = url?.let { Uri.parse(it) }
        val external = u != null && (u.scheme == "http" || u.scheme == "https") && !Config.isInternal(u.host)
        actionBar.visibility = if (external) View.VISIBLE else View.GONE
    }

    private fun openExternal(uri: Uri, chrome: Boolean = false) {
        val i = Intent(Intent.ACTION_VIEW, uri)
        try {
            if (chrome) startActivity(Intent(i).setPackage("com.android.chrome")) else startActivity(i)
        } catch (_: ActivityNotFoundException) {
            try { startActivity(i) } catch (_: ActivityNotFoundException) {}
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume(); if (downloader == null) downloader = findDownloader() }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); web.destroy(); super.onDestroy() }
}
