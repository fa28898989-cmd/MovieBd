package com.personal.movielink

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var root: FrameLayout
    private lateinit var chromeBtn: TextView
    private lateinit var progress: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private val resetAlpha = Runnable { web.alpha = 1f }
    @Volatile private var downloadPage = false   // light/download page: no loading effects
    private var loadingInternal = true
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    private val accent = Color.parseColor("#2E9E6B")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        web = WebView(this).apply { setBackgroundColor(Color.BLACK) }
        refresh = SwipeRefreshLayout(this).apply {
            addView(web)
            setProgressBackgroundColorSchemeColor(Color.parseColor("#1E1E1E"))
            setColorSchemeColors(accent)
        }
        root.addView(refresh, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
            progressTintList = ColorStateList.valueOf(accent)
            progressBackgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        }
        root.addView(progress, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3), Gravity.TOP))

        chromeBtn = TextView(this).apply {
            text = "Open in Chrome"
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#262626"))
                cornerRadius = dp(22).toFloat()
            }
            setPadding(dp(16), dp(10), dp(16), dp(10))
            visibility = View.GONE
            setOnClickListener { web.url?.let { openExternal(Uri.parse(it), chrome = true) } }
        }
        root.addView(chromeBtn, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END
        ).apply { setMargins(0, 0, dp(16), dp(24)) })
        setContentView(root)

        refresh.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        refresh.setOnRefreshListener {
            val u = web.url
            if (u.isNullOrEmpty() || u.startsWith("data:") || u == "about:blank") web.loadUrl(Config.HOME_URL)
            else web.reload()
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString.replace("; wv", "")
        }
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        web.addJavascriptInterface(Bridge(), "AmoledBridge")
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(web, Cosmetic.EARLY_JS, setOf("*"))
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return if (AdBlocker.shouldBlock(request.url))
                    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme
                if (scheme != "http" && scheme != "https") return true      // block intent://, market:// etc.
                if (AdBlocker.shouldBlock(uri)) return true
                if (!request.isForMainFrame) return false
                if (Config.isInternal(uri.host)) { navStarting(uri); return false }
                // Other sites (download/file hosts) load INSIDE the app, but only after a real tap
                // or a server redirect. Scripted ad redirects (no tap) are blocked.
                return !(request.hasGesture() || request.isRedirect)
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                loadingInternal = Config.isInternal(url?.let { Uri.parse(it).host })
                downloadPage = false
                updateChromeBtn(url)
            }

            override fun onPageCommitVisible(view: WebView, url: String?) { showWeb() }

            override fun onPageFinished(view: WebView, url: String?) {
                refresh.isRefreshing = false
                updateChromeBtn(url)
                showWeb()
                view.evaluateJavascript(Cosmetic.PAGE_JS, null)
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    refresh.isRefreshing = false
                    showWeb()
                    view.loadData(
                        "<body style='background:#000;color:#ccc;font-family:sans-serif;text-align:center;padding-top:30vh'>" +
                            "<h2>Can't load the site</h2><p>Check your connection, then pull down to retry.</p></body>",
                        "text/html", "utf-8"
                    )
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(v: WebView, d: Boolean, g: Boolean, m: android.os.Message?) = false

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                val show = loadingInternal && !downloadPage && newProgress in 1..99
                progress.visibility = if (show) View.VISIBLE else View.GONE
            }

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view; customCb = cb
                view.setBackgroundColor(Color.BLACK)
                refresh.visibility = View.GONE
                root.addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                immersive(true)
            }

            override fun onHideCustomView() { exitFullscreen() }
        }

        web.setDownloadListener { url, ua, cd, mime, _ ->
            val uri = Uri.parse(url)
            progress.visibility = View.GONE   // a download isn't a page load: clear any loading effect
            showWeb()
            // 1) Hand the link to IDM / 1DM if installed
            for (pkg in Config.DOWNLOAD_APPS) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))
                    return@setDownloadListener
                } catch (_: ActivityNotFoundException) {
                } catch (_: SecurityException) {
                }
            }
            // 2) Otherwise use Android's built-in downloader
            try {
                val req = DownloadManager.Request(uri)
                req.setMimeType(mime)
                req.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                req.addRequestHeader("User-Agent", ua)
                req.addRequestHeader("Referer", web.url ?: Config.HOME_URL)
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Downloading…", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                openExternal(uri)
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> exitFullscreen()
                    web.canGoBack() -> web.goBack()
                    else -> finish()
                }
            }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl(Config.HOME_URL)
    }

    // Instant tap feedback: dim the old page and show the progress bar right away
    private fun navStarting(target: Uri) {
        // No loading effects on download pages / when heading to download links
        if (downloadPage || target.toString().contains("download", ignoreCase = true)) return
        web.alpha = 0.35f
        progress.progress = 5
        progress.visibility = View.VISIBLE
        handler.removeCallbacks(resetAlpha)
        handler.postDelayed(resetAlpha, 3000)   // safety: never stay dimmed
    }

    // New page painted: fade it in smoothly
    private fun showWeb() {
        handler.removeCallbacks(resetAlpha)
        web.animate().cancel()
        web.animate().alpha(1f).setDuration(140).start()
    }

    inner class Bridge {
        @JavascriptInterface
        fun light(isLight: Boolean) {
            runOnUiThread {
                downloadPage = isLight
                if (isLight) { progress.visibility = View.GONE; showWeb() }
            }
        }
    }

    private fun exitFullscreen() {
        customView?.let { root.removeView(it) }
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        refresh.visibility = View.VISIBLE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        immersive(false)
    }

    private fun immersive(on: Boolean) {
        val c = WindowInsetsControllerCompat(window, root)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (on) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // Shows the "Open in Chrome" button only while you're on a page outside the movie site (e.g. download pages)
    private fun updateChromeBtn(url: String?) {
        val u = url?.let { Uri.parse(it) }
        val external = u != null && (u.scheme == "http" || u.scheme == "https") && !Config.isInternal(u.host)
        chromeBtn.visibility = if (external) View.VISIBLE else View.GONE
    }

    private fun openExternal(uri: Uri, chrome: Boolean = false) {
        val i = Intent(Intent.ACTION_VIEW, uri)
        try {
            if (chrome) startActivity(Intent(i).setPackage("com.android.chrome")) else startActivity(i)
        } catch (_: ActivityNotFoundException) {
            try { startActivity(i) } catch (_: ActivityNotFoundException) {}
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); web.destroy(); super.onDestroy() }
}
