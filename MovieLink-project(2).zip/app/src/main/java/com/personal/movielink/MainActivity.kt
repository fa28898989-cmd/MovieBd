package com.personal.movielink

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var root: FrameLayout
    private lateinit var chromeBtn: TextView
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        root = FrameLayout(this)
        web = WebView(this)
        refresh = SwipeRefreshLayout(this).apply { addView(web) }
        root.addView(refresh, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        chromeBtn = TextView(this).apply {
            text = "Open in Chrome"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#E50914"))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            visibility = View.GONE
            setOnClickListener { web.url?.let { openExternal(Uri.parse(it), chrome = true) } }
        }
        root.addView(chromeBtn, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END
        ).apply { setMargins(0, 0, dp(16), dp(24)) })
        setContentView(root)

        refresh.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        refresh.setOnRefreshListener {
            val u = web.url
            if (u.isNullOrEmpty() || u.startsWith("data:") || u == "about:blank") web.loadUrl(Config.HOME_URL)
            else web.reload()
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(web, Cosmetic.EARLY_JS, setOf("*"))
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return if (AdBlocker.shouldBlock(request.url))
                    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme
                if (scheme != "http" && scheme != "https") return true      // block intent://, market:// etc.
                if (AdBlocker.shouldBlock(uri)) return true
                if (!request.isForMainFrame) return false
                if (Config.isInternal(uri.host)) return false
                // Other sites (download/file hosts) load INSIDE the app, but only after a real tap
                // or a server redirect. Scripted ad redirects (no tap) are blocked.
                return !(request.hasGesture() || request.isRedirect)
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                updateChromeBtn(url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                refresh.isRefreshing = false
                updateChromeBtn(url)
                view.evaluateJavascript(Cosmetic.PAGE_JS, null)
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    refresh.isRefreshing = false
                    view.loadData(
                        "<body style='background:#000;color:#ccc;font-family:sans-serif;text-align:center;padding-top:30vh'>" +
                            "<h2>Can't load the site</h2><p>Check your connection, then pull down to retry.</p></body>",
                        "text/html", "utf-8"
                    )
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(v: WebView, d: Boolean, g: Boolean, m: android.os.Message?) = false

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view; customCb = cb
                refresh.visibility = View.GONE
                root.addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                immersive(true)
            }

            override fun onHideCustomView() { exitFullscreen() }
        }

        web.setDownloadListener { url, ua, cd, mime, _ ->
            val uri = Uri.parse(url)
            // 1) Hand the link to IDM / 1DM if installed
            for (pkg in Config.DOWNLOAD_APPS) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))
                    return@setDownloadListener
                } catch (_: ActivityNotFoundException) {
                } catch (_: SecurityException) {
                }
            }
            // 2) Otherwise use Android's built-in downloader
            try {
                val req = DownloadManager.Request(uri)
                req.setMimeType(mime)
                req.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                req.addRequestHeader("User-Agent", ua)
                req.addRequestHeader("Referer", web.url ?: Config.HOME_URL)
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Downloading…", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                openExternal(uri)
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> exitFullscreen()
                    web.canGoBack() -> web.goBack()
                    else -> finish()
                }
            }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl(Config.HOME_URL)
    }

    private fun exitFullscreen() {
        customView?.let { root.removeView(it) }
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        refresh.visibility = View.VISIBLE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        immersive(false)
    }

    private fun immersive(on: Boolean) {
        val c = WindowInsetsControllerCompat(window, root)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (on) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // Shows the "Open in Chrome" button only while you're on a page outside the movie site (e.g. download pages)
    private fun updateChromeBtn(url: String?) {
        val u = url?.let { Uri.parse(it) }
        val external = u != null && (u.scheme == "http" || u.scheme == "https") && !Config.isInternal(u.host)
        chromeBtn.visibility = if (external) View.VISIBLE else View.GONE
    }

    private fun openExternal(uri: Uri, chrome: Boolean = false) {
        val i = Intent(Intent.ACTION_VIEW, uri)
        try {
            if (chrome) startActivity(Intent(i).setPackage("com.android.chrome")) else startActivity(i)
        } catch (_: ActivityNotFoundException) {
            try { startActivity(i) } catch (_: ActivityNotFoundException) {}
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
