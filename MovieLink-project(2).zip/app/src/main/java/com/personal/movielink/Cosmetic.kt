package com.personal.movielink

object Cosmetic {
    // Runs before any page script: neutralise window.open popups
    // Returns a dummy window so ad scripts think the popup opened and don't fall back to redirecting the page
    val EARLY_JS = """
window.open=function(){return {closed:false,focus:function(){},blur:function(){},close:function(){},postMessage:function(){},document:{write:function(){},close:function(){}},location:{href:''}};};
""".trimIndent()

    // Runs after load: hide leftover ad boxes and remove invisible click-hijack overlays
    val PAGE_JS = """
(function(){
  if(window.__abk)return; window.__abk=1;
  var st=document.createElement('style');
  st.textContent='ins.adsbygoogle,[id^="google_ads"],[class*="popunder"],[id*="popunder"],'
   +'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="adsterra"],'
   +'div[id^="ad-"],div[class^="ad-"],.ad-banner,.ads-banner,.adsbox{display:none!important}';
  (document.head||document.documentElement).appendChild(st);
  function sweep(){
    var vw=window.innerWidth, vh=window.innerHeight;
    var els=document.querySelectorAll('div,a,span');
    for(var i=0;i<els.length;i++){
      var e=els[i], cs=getComputedStyle(e);
      if(cs.position!=='fixed'&&cs.position!=='absolute')continue;
      var z=parseInt(cs.zIndex)||0; if(z<1000)continue;
      var r=e.getBoundingClientRect();
      if(r.width>=vw*0.9&&r.height>=vh*0.9&&e.textContent.trim()===''&&!e.querySelector('video,img,canvas')){
        e.remove();
      }
    }
  }
  var t=null;
  new MutationObserver(function(){ if(t)return; t=setTimeout(function(){t=null;sweep();},400); })
    .observe(document.documentElement,{childList:true,subtree:true});
  sweep();
})();
""".trimIndent()
}
