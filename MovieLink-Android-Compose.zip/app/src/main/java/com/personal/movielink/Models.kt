package com.personal.movielink

data class MediaCard(
    val title: String,
    val url: String,
    val posterUrl: String,
    val quality: String = "",
    val language: String = "",
    val type: String = "",
    val badge: String = ""
)

data class CatalogSection(
    val title: String,
    val items: List<MediaCard>,
    val moreUrl: String? = null
)

data class CategoryChip(
    val label: String,
    val url: String
)

data class OttPlatform(
    val name: String,
    val url: String,
    val iconUrl: String,
    val newBadge: String = "",
    val accentHex: String = "#22D3EE"
)

data class CatalogPage(
    val url: String,
    val pageTitle: String,
    val sections: List<CatalogSection>,
    val categories: List<CategoryChip>,
    val ottPlatforms: List<OttPlatform> = emptyList(),
    val ottAllUrl: String? = null,
    val nextPageUrl: String? = null,
    val isSearchOrGrid: Boolean = false
)

data class CastMember(
    val name: String,
    val role: String,
    val avatarUrl: String,
    val profileUrl: String
)

data class DownloadOption(
    val label: String,
    val decodedUrl: String,
    val isZipPack: Boolean = false
)

data class EpisodeItem(
    val title: String,
    val seasonNumber: Int?,
    val episodeNumber: Int?,
    val isNew: Boolean,
    val downloads: List<DownloadOption>
)

data class MediaDetail(
    val url: String,
    val title: String,
    val subtitle: String,
    val posterUrl: String,
    val type: String,
    val language: String,
    val quality: String,
    val scheduleText: String,
    val trailerYoutubeId: String?,
    val watchEmbedUrl: String?,
    val storyline: String,
    val extraInfoLines: List<String>,
    val cast: List<CastMember>,
    val screenshotUrls: List<String>,
    val downloadLinks: List<DownloadOption>,
    val episodes: List<EpisodeItem>,
    val seasonZipLinks: List<DownloadOption>,
    val relatedItems: List<MediaCard>,
    val communityRatingSummary: String? = null
)

data class HistoryItem(
    val title: String,
    val url: String,
    val posterUrl: String = "",
    val timestamp: Long
)

data class MyListItem(
    val url: String,
    val title: String,
    val posterUrl: String,
    val type: String,
    val quality: String,
    val language: String,
    val addedAt: Long
)

data class UserSettings(
    val mirrorUrl: String = Config.DEFAULT_HOME_URL,
    val resumeLastPage: Boolean = true,
    val lastVisitedUrl: String? = null,
    val downloaderMode: Config.DownloaderMode = Config.DownloaderMode.AUTO,
    val videoActionMode: Config.VideoActionMode = Config.VideoActionMode.ASK,
    val hideVideoProgressBar: Boolean = true,
    val playerBrightnessSync: Boolean = true,
    val desktopMode: Boolean = false,
    val adBlockEnabled: Boolean = true,
    val sitePolishEnabled: Boolean = true,
    val showOttSection: Boolean = true,
    val floatingNavBar: Boolean = false,
    val floatingNavHeightDp: Int = 56,
    val floatingNavWidthPercent: Int = 88,
    val floatingNavSpacingDp: Int = 14,
    val floatingNavAlphaPercent: Int = 90,
    val floatingNavColorHex: String? = null,
    val detailBoxEnabled: Boolean = true,
    val detailBoxStyle: Config.DetailBoxStyle = Config.DetailBoxStyle.ROUNDED,
    val detailBoxOpacityPercent: Int = 85,
    val detailBoxSizePercent: Int = 100,
    val detailBoxColorHex: String = "#71717A",
    val bgPresetId: String = Config.BgPreset.BLACK.id,
    val customBgHex: String? = null,
    val themePresetId: String = Config.ThemePreset.CYAN.id,
    val customThemeHex: String? = null,
    val customBlockedDomains: Set<String> = emptySet(),
    val customAllowedDomains: Set<String> = emptySet()
)

data class PlayerLaunchRequest(
    val streamUrl: String,
    val title: String,
    val subtitle: String = "",
    val refererUrl: String,
    val isEmbedPage: Boolean = false
)
