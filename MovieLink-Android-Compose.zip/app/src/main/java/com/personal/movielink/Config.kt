package com.personal.movielink

import android.graphics.Color
import android.net.Uri
import androidx.core.graphics.ColorUtils
import java.util.Locale

object Config {
    const val DEFAULT_HOME_URL = "https://ss257n.movielinkbd.at/"
    val DEFAULT_INTERNAL_SUFFIXES = listOf(
        "movielinkbd.at",
        "movielinkbd.com",
        "movielinkbd.one",
        "movielinkbd.work",
        "movielinkbd.shop",
        "movielinkbd.tv",
        "movielink.tv"
    )

    const val MOBILE_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    const val DESKTOP_USER_AGENT =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

    data class AppOption(val label: String, val packageName: String)

    val DOWNLOAD_APPS = listOf(
        AppOption("1DM+", "idm.internet.download.manager.plus"),
        AppOption("1DM", "idm.internet.download.manager"),
        AppOption("ADM", "idm.internet.download.manager.adm.lite"),
        AppOption("ADM", "com.dv.adm")
    )

    val PLAYER_APPS = listOf(
        AppOption("VLC", "org.videolan.vlc"),
        AppOption("MX Player", "com.mxtech.videoplayer.ad"),
        AppOption("MX Player Pro", "com.mxtech.videoplayer.pro")
    )

    enum class ThemePreset(
        val id: String,
        val label: String,
        val accentHex: String,
        val fgHex: String,
        val borderHex: String
    ) {
        BLACK("black", "Black", "#000000", "#E4E4E7", "#3F3F46"),
        WHITE("white", "White", "#FFFFFF", "#FFFFFF", "#D4D4D8"),
        GREY("grey", "Grey", "#BDBDBD", "#D4D4D8", "#71717A"),
        GREEN("green", "Green", "#22C55E", "#4ADE80", "#22C55E"),
        BLUE("blue", "Blue", "#3B82F6", "#60A5FA", "#3B82F6"),
        RED("red", "Red", "#EF4444", "#F87171", "#EF4444"),
        PURPLE("purple", "Purple", "#A855F7", "#C084FC", "#A855F7"),
        AMBER("amber", "Amber", "#F59E0B", "#FBBF24", "#F59E0B"),
        CYAN("cyan", "Cyan", "#06B6D4", "#22D3EE", "#06B6D4");

        companion object {
            fun fromId(id: String?): ThemePreset =
                entries.firstOrNull { it.id == id } ?: CYAN
        }
    }

    enum class BgPreset(
        val id: String,
        val label: String,
        val pageHex: String,
        val cardHex: String,
        val altHex: String
    ) {
        BLACK("black", "Black", "#000000", "#0C0C0E", "#141418"),
        GREY("grey", "Grey", "#1C1C1E", "#262629", "#303034"),
        BLUE("blue", "Blue", "#0B1426", "#13203B", "#1A2B4D"),
        GREEN("green", "Green", "#081810", "#0F261B", "#153425"),
        WINE("wine", "Wine", "#1A090D", "#280F16", "#35151E"),
        PURPLE("purple", "Purple", "#130B24", "#1E1238", "#28184B"),
        BROWN("brown", "Warm", "#1A130B", "#261C11", "#332517"),
        TEAL("teal", "Teal", "#07191C", "#0D272C", "#13363D");

        companion object {
            fun fromId(id: String?): BgPreset =
                entries.firstOrNull { it.id == id } ?: BLACK
        }
    }

    data class ResolvedTheme(
        val id: String,
        val label: String,
        val accentHex: String,
        val fgHex: String,
        val borderHex: String,
        val isCustom: Boolean
    ) {
        fun accentInt(): Int = Color.parseColor(accentHex)
        fun fgInt(): Int = Color.parseColor(fgHex)
        fun borderInt(): Int = Color.parseColor(borderHex)
        fun isBrightAccent(): Boolean = ColorUtils.calculateLuminance(accentInt()) > 0.42
        fun isDarkAccent(): Boolean = ColorUtils.calculateLuminance(accentInt()) < 0.08
        fun onPureAccentInt(): Int = if (ColorUtils.calculateLuminance(accentInt()) > 0.42) {
            Color.parseColor("#0A0D12")
        } else {
            Color.WHITE
        }
        fun onAccentInt(): Int = if (ColorUtils.calculateLuminance(fgInt()) > 0.42) {
            Color.parseColor("#0A0D12")
        } else {
            Color.WHITE
        }
    }

    data class ResolvedBg(
        val id: String,
        val label: String,
        val pageHex: String,
        val cardHex: String,
        val altHex: String,
        val isLight: Boolean,
        val isCustom: Boolean
    ) {
        fun pageInt(): Int = Color.parseColor(pageHex)
        fun cardInt(): Int = Color.parseColor(cardHex)
        fun altInt(): Int = Color.parseColor(altHex)
    }

    fun toHex(color: Int): String = String.format(Locale.US, "#%06X", 0xFFFFFF and color)

    fun resolveTheme(presetId: String, customThemeHex: String?): ResolvedTheme {
        if (presetId == "custom" && !customThemeHex.isNullOrBlank()) {
            return try {
                val base = Color.parseColor(customThemeHex)
                val lum = ColorUtils.calculateLuminance(base)
                val fg = if (lum < 0.06) {
                    Color.parseColor("#E4E4E7")
                } else {
                    val hsvFg = FloatArray(3)
                    Color.colorToHSV(base, hsvFg)
                    hsvFg[2] = (hsvFg[2] + 0.12f).coerceIn(0.62f, 1f)
                    Color.HSVToColor(hsvFg)
                }

                val border = if (lum < 0.06) {
                    Color.parseColor("#3F3F46")
                } else {
                    val hsvBorder = FloatArray(3)
                    Color.colorToHSV(base, hsvBorder)
                    hsvBorder[2] = hsvBorder[2].coerceIn(0.45f, 0.92f)
                    Color.HSVToColor(hsvBorder)
                }

                ResolvedTheme("custom", "Custom", toHex(base), toHex(fg), toHex(border), true)
            } catch (_: Exception) {
                val p = ThemePreset.CYAN
                ResolvedTheme(p.id, p.label, p.accentHex, p.fgHex, p.borderHex, false)
            }
        }
        val p = ThemePreset.fromId(presetId)
        return ResolvedTheme(p.id, p.label, p.accentHex, p.fgHex, p.borderHex, false)
    }

    fun resolveBg(presetId: String, customBgHex: String?): ResolvedBg {
        if (presetId == "custom" && !customBgHex.isNullOrBlank()) {
            return try {
                val base = Color.parseColor(customBgHex)
                val isLight = ColorUtils.calculateLuminance(base) > 0.45
                val hsvCard = FloatArray(3)
                Color.colorToHSV(base, hsvCard)
                hsvCard[2] = if (isLight) (hsvCard[2] - 0.06f).coerceIn(0.1f, 0.96f)
                else (hsvCard[2] + 0.06f).coerceIn(0.05f, 0.95f)
                val card = Color.HSVToColor(hsvCard)

                val hsvAlt = FloatArray(3)
                Color.colorToHSV(base, hsvAlt)
                hsvAlt[2] = if (isLight) (hsvAlt[2] - 0.11f).coerceIn(0.1f, 0.92f)
                else (hsvAlt[2] + 0.11f).coerceIn(0.08f, 0.95f)
                val alt = Color.HSVToColor(hsvAlt)

                ResolvedBg("custom", "Custom", toHex(base), toHex(card), toHex(alt), isLight, true)
            } catch (_: Exception) {
                val p = BgPreset.BLACK
                ResolvedBg(p.id, p.label, p.pageHex, p.cardHex, p.altHex, false, false)
            }
        }
        val p = BgPreset.fromId(presetId)
        return ResolvedBg(p.id, p.label, p.pageHex, p.cardHex, p.altHex, false, false)
    }

    enum class DownloaderMode(val id: String, val label: String, val packageName: String? = null) {
        AUTO("auto", "Auto (1DM+ → 1DM → ADM → Built-in)"),
        IDM_PLUS("idm_plus", "1DM+", "idm.internet.download.manager.plus"),
        IDM("idm", "1DM", "idm.internet.download.manager"),
        ADM("adm", "ADM", "idm.internet.download.manager.adm.lite"),
        BUILTIN("builtin", "Android Built-in DownloadManager"),
        ASK("ask", "Ask every time");

        companion object {
            fun fromId(id: String?): DownloaderMode =
                entries.firstOrNull { it.id == id } ?: AUTO
        }
    }

    enum class VideoActionMode(val id: String, val label: String) {
        ASK("ask", "Ask (Play or Download)"),
        DOWNLOAD("download", "Always Download"),
        EXTERNAL_PLAYER("player", "Play in VLC / MX Player");

        companion object {
            fun fromId(id: String?): VideoActionMode =
                entries.firstOrNull { it.id == id } ?: ASK
        }
    }

    enum class DetailBoxStyle(val id: String, val label: String) {
        ROUNDED("rounded", "Rounded"),
        SQUARE("square", "Square"),
        CIRCLE("circle", "Circle");

        companion object {
            fun fromId(id: String?): DetailBoxStyle =
                entries.firstOrNull { it.id == id } ?: ROUNDED
        }
    }

    fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return DEFAULT_HOME_URL
        val withScheme = if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) {
            trimmed
        } else {
            "https://$trimmed"
        }
        val uri = Uri.parse(withScheme)
        if (uri.host.isNullOrBlank()) return DEFAULT_HOME_URL
        return if (uri.path.isNullOrEmpty() && !withScheme.endsWith("/")) "$withScheme/" else withScheme
    }

    fun extractRootDomain(host: String): String {
        val clean = host.lowercase(Locale.US).trim()
        val parts = clean.split('.').filter { it.isNotEmpty() }
        return if (parts.size >= 3) "${parts[parts.size - 2]}.${parts[parts.size - 1]}" else clean
    }

    fun internalSuffixes(mirrorUrl: String): List<String> {
        val list = linkedSetOf<String>()
        list.addAll(DEFAULT_INTERNAL_SUFFIXES)
        val mirrorHost = Uri.parse(mirrorUrl).host?.lowercase(Locale.US)
        if (!mirrorHost.isNullOrBlank()) {
            list.add(mirrorHost)
            list.add(extractRootDomain(mirrorHost))
        }
        return list.toList()
    }

    fun isInternal(host: String?, mirrorUrl: String): Boolean {
        val h = host?.lowercase(Locale.US) ?: return false
        return internalSuffixes(mirrorUrl).any { suffix -> h == suffix || h.endsWith(".$suffix") }
    }
}
