package com.personal.movielink.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.FormatListBulleted
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.ColorUtils
import coil.ImageLoader
import coil.compose.AsyncImage
import com.personal.movielink.AppSettingsStore
import com.personal.movielink.CatalogPage
import com.personal.movielink.CategoryChip
import com.personal.movielink.HistoryItem
import com.personal.movielink.MediaCard
import com.personal.movielink.MyListItem
import com.personal.movielink.OttPlatform
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlin.math.absoluteValue

private enum class HomeBottomTab { HOME, SEARCH, LIBRARY }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CatalogScreen(
    catalog: CatalogPage?,
    isLoading: Boolean,
    errorMessage: String?,
    settings: UserSettings,
    imageLoader: ImageLoader,
    myList: List<MyListItem>,
    history: List<HistoryItem>,
    onRefresh: () -> Unit,
    onSearch: (String) -> Unit,
    onOpenUrl: (String) -> Unit,
    onOpenMedia: (MediaCard) -> Unit,
    onOpenHistoryItem: (HistoryItem) -> Unit,
    onOpenMyListItem: (MyListItem) -> Unit,
    onRemoveMyList: (String) -> Unit,
    onClearHistory: () -> Unit,
    onOpenHistoryDialog: () -> Unit,
    onOpenFallbackWeb: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val keyboard = LocalSoftwareKeyboardController.current
    var activeBottomTab by remember { mutableStateOf(HomeBottomTab.HOME) }
    var librarySection by remember { mutableIntStateOf(0) } // 0 = My List, 1 = History
    var searchText by remember { mutableStateOf("") }
    var showCategoriesModal by remember { mutableStateOf(false) }

    val baseMirror = remember(settings.mirrorUrl) { settings.mirrorUrl.trimEnd('/') }
    val seriesUrl = remember(catalog, baseMirror) {
        catalog?.categories?.firstOrNull { it.url.contains("/type/series", true) }?.url
            ?: "$baseMirror/type/series"
    }
    val moviesUrl = remember(catalog, baseMirror) {
        catalog?.categories?.firstOrNull { it.url.contains("/type/movies", true) }?.url
            ?: "$baseMirror/type/movies"
    }

    val currentPath = catalog?.url.orEmpty().lowercase()
    val isTvActive = currentPath.contains("/type/series")
    val isMoviesActive = currentPath.contains("/type/movies")
    val isSearchCatalog = currentPath.contains("/search")

    // If a search request returns results, stay cleanly on SEARCH tab so user sees results immediately
    LaunchedEffect(catalog?.url) {
        if (catalog?.url?.contains("/search", ignoreCase = true) == true) {
            activeBottomTab = HomeBottomTab.SEARCH
        }
    }

    val floatingExtraBottom = if (settings.floatingNavBar) {
        (settings.floatingNavHeightDp.coerceIn(44, 80) + settings.floatingNavSpacingDp.coerceIn(4, 40) + 18).dp
    } else {
        0.dp
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.pageBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.weight(1f)) {
            when (activeBottomTab) {
                HomeBottomTab.HOME -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Top Bar matching Reference Image 2: Monogram + TV Shows + Movies + Categories
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(palette.boxBg)
                                    .border(1.2.dp, palette.boxBorder, RoundedCornerShape(9.dp))
                                    .clickable { onOpenUrl(settings.mirrorUrl) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "M",
                                    color = palette.fg,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            TopFilterPill(
                                label = "TV Shows",
                                selected = isTvActive,
                                onClick = {
                                    if (isTvActive) onOpenUrl(settings.mirrorUrl) else onOpenUrl(seriesUrl)
                                },
                                modifier = Modifier.weight(1f)
                            )

                            TopFilterPill(
                                label = "Movies",
                                selected = isMoviesActive,
                                onClick = {
                                    if (isMoviesActive) onOpenUrl(settings.mirrorUrl) else onOpenUrl(moviesUrl)
                                },
                                modifier = Modifier.weight(1f)
                            )

                            TopFilterPill(
                                label = "Categories",
                                selected = showCategoriesModal || (catalog?.isSearchOrGrid == true && !isTvActive && !isMoviesActive && !isSearchCatalog),
                                hasCaret = true,
                                onClick = { showCategoriesModal = true },
                                modifier = Modifier.weight(1.1f)
                            )
                        }

                        PullToRefreshBox(
                            isRefreshing = isLoading && catalog != null,
                            onRefresh = onRefresh,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            when {
                                isLoading && catalog == null -> {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            CircularProgressIndicator(color = palette.fg)
                                            Spacer(Modifier.height(12.dp))
                                            Text(
                                                text = "Loading live catalog…",
                                                color = palette.textSecondary,
                                                fontSize = 13.5.sp
                                            )
                                        }
                                    }
                                }
                                errorMessage != null && catalog == null -> {
                                    ErrorRetryState(
                                        message = errorMessage,
                                        onRetry = onRefresh,
                                        onOpenWeb = onOpenFallbackWeb,
                                        onOpenSettings = onOpenSettings
                                    )
                                }
                                catalog == null || catalog.sections.isEmpty() -> {
                                    ErrorRetryState(
                                        message = "No titles found on this page.",
                                        onRetry = onRefresh,
                                        onOpenWeb = onOpenFallbackWeb,
                                        onOpenSettings = onOpenSettings
                                    )
                                }
                                catalog.isSearchOrGrid -> {
                                    val gridItems = catalog.sections.flatMap { it.items }.distinctBy { it.url }
                                    LazyColumn(
                                        modifier = Modifier.fillMaxSize(),
                                        contentPadding = PaddingValues(
                                            start = 14.dp,
                                            top = 14.dp,
                                            end = 14.dp,
                                            bottom = 14.dp + floatingExtraBottom
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        item {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = catalog.pageTitle,
                                                    fontSize = 16.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = palette.textPrimary,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                Text(
                                                    text = "Back to Home",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = palette.fg,
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .clickable { onOpenUrl(settings.mirrorUrl) }
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                        val rows = gridItems.chunked(2)
                                        items(rows) { rowCards ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                rowCards.forEach { card ->
                                                    MediaPosterCard(
                                                        card = card,
                                                        imageLoader = imageLoader,
                                                        onClick = { onOpenMedia(card) },
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                }
                                                if (rowCards.size == 1) {
                                                    Spacer(Modifier.weight(1f))
                                                }
                                            }
                                        }
                                        if (catalog.nextPageUrl != null) {
                                            item {
                                                OutlinedButton(
                                                    onClick = { onOpenUrl(catalog.nextPageUrl) },
                                                    shape = RoundedCornerShape(12.dp),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Text("Next Page", color = palette.fg, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                                else -> {
                                    val heroItems = remember(catalog) {
                                        val movieSectionItems = catalog.sections
                                            .filter {
                                                it.title.equals("Movies", ignoreCase = true) ||
                                                    (it.title.contains("Movie", ignoreCase = true) &&
                                                        !it.title.contains("Recently", ignoreCase = true))
                                            }
                                            .flatMap { it.items }
                                        val otherMovieItems = catalog.sections
                                            .filterNot {
                                                it.title.contains("Recently Updated", ignoreCase = true) ||
                                                    it.title.contains("Recently Uploaded", ignoreCase = true)
                                            }
                                            .flatMap { it.items }
                                            .filter { it.url.contains("/movie/", ignoreCase = true) }
                                        val nonRecentFallback = catalog.sections
                                            .filterNot {
                                                it.title.contains("Recently Updated", ignoreCase = true) ||
                                                    it.title.contains("Recently Uploaded", ignoreCase = true)
                                            }
                                            .flatMap { it.items }
                                        val prioritized = (movieSectionItems + otherMovieItems).ifEmpty {
                                            nonRecentFallback.ifEmpty { catalog.sections.flatMap { it.items } }
                                        }
                                        prioritized
                                            .filter { it.posterUrl.isNotBlank() }
                                            .distinctBy { it.url }
                                            .take(6)
                                    }

                                    // Real visit history items with posters (optional Continue Watching row, zero mock data)
                                    val continueItems = remember(history) {
                                        history.filter { item ->
                                            item.posterUrl.isNotBlank() &&
                                                (item.url.contains("/movie/", true) ||
                                                    item.url.contains("/series/", true) ||
                                                    item.url.contains("/drama/", true) ||
                                                    item.url.contains("/anime/", true))
                                        }.take(10)
                                    }

                                    LazyColumn(
                                        modifier = Modifier.fillMaxSize(),
                                        contentPadding = PaddingValues(top = 4.dp, bottom = 18.dp + floatingExtraBottom),
                                        verticalArrangement = Arrangement.spacedBy(18.dp)
                                    ) {
                                        if (heroItems.isNotEmpty()) {
                                            item {
                                                HeroCoverflowCarousel(
                                                    items = heroItems,
                                                    imageLoader = imageLoader,
                                                    onOpenMedia = onOpenMedia
                                                )
                                            }
                                        }

                                        if (continueItems.isNotEmpty()) {
                                            item {
                                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(horizontal = 14.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "Continue Watching",
                                                            fontSize = 16.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = palette.textPrimary
                                                        )
                                                        Text(
                                                            text = "History",
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = palette.fg,
                                                            modifier = Modifier
                                                                .clip(RoundedCornerShape(8.dp))
                                                                .clickable(onClick = onOpenHistoryDialog)
                                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                                        )
                                                    }
                                                    LazyRow(
                                                        contentPadding = PaddingValues(horizontal = 14.dp),
                                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                                    ) {
                                                        items(continueItems, key = { it.url }) { h ->
                                                            ContinueWatchingCard(
                                                                item = h,
                                                                imageLoader = imageLoader,
                                                                onClick = { onOpenHistoryItem(h) }
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        if (settings.showOttSection && catalog.ottPlatforms.isNotEmpty()) {
                                            item(key = "watch_by_ott") {
                                                WatchByOttSection(
                                                    platforms = catalog.ottPlatforms,
                                                    imageLoader = imageLoader,
                                                    onOpenUrl = onOpenUrl
                                                )
                                            }
                                        }

                                        // Live site sections starting with Recently Updated
                                        items(catalog.sections, key = { it.title + (it.items.firstOrNull()?.url ?: "") }) { section ->
                                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 14.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = section.title,
                                                        fontSize = 16.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = palette.textPrimary,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    if (section.moreUrl != null) {
                                                        Text(
                                                            text = "View all",
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = palette.fg,
                                                            modifier = Modifier
                                                                .clip(RoundedCornerShape(8.dp))
                                                                .clickable { onOpenUrl(section.moreUrl) }
                                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                                        )
                                                    }
                                                }

                                                LazyRow(
                                                    contentPadding = PaddingValues(horizontal = 14.dp),
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    items(section.items, key = { it.url }) { card ->
                                                        HomeRailPosterCard(
                                                            card = card,
                                                            imageLoader = imageLoader,
                                                            onClick = { onOpenMedia(card) }
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        if (catalog.nextPageUrl != null) {
                                            item {
                                                Box(modifier = Modifier.padding(horizontal = 14.dp)) {
                                                    OutlinedButton(
                                                        onClick = { onOpenUrl(catalog.nextPageUrl) },
                                                        shape = RoundedCornerShape(12.dp),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Text("Next Page", color = palette.fg, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                HomeBottomTab.SEARCH -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = 12.dp)
                    ) {
                        Text(
                            text = "Search",
                            color = palette.textPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = searchText,
                            onValueChange = { searchText = it },
                            placeholder = {
                                Text(
                                    text = "Search Movie or Series in English",
                                    fontSize = 13.5.sp,
                                    color = palette.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            leadingIcon = {
                                Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.fg)
                            },
                            trailingIcon = {
                                if (searchText.isNotEmpty()) {
                                    IconButton(onClick = { searchText = "" }) {
                                        Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = palette.textSecondary)
                                    }
                                }
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(
                                onSearch = {
                                    if (searchText.isNotBlank()) {
                                        keyboard?.hide()
                                        onSearch(searchText)
                                    }
                                }
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = palette.cardBg,
                                unfocusedContainerColor = palette.cardBg,
                                focusedBorderColor = palette.boxBorder,
                                unfocusedBorderColor = palette.border.copy(alpha = 0.45f),
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary,
                                cursorColor = palette.fg
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp)
                        )

                        Spacer(Modifier.height(10.dp))

                        if (catalog != null && catalog.categories.isNotEmpty() && !isSearchCatalog) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(
                                        start = 14.dp,
                                        top = 14.dp,
                                        end = 14.dp,
                                        bottom = 14.dp + floatingExtraBottom
                                    ),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "Browse by Genre & Language",
                                    color = palette.textSecondary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    catalog.categories.forEach { cat ->
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(palette.boxBg)
                                                .border(1.dp, palette.boxBorder.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                                .clickable {
                                                    activeBottomTab = HomeBottomTab.HOME
                                                    onOpenUrl(cat.url)
                                                }
                                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                        ) {
                                            Text(
                                                text = cat.label,
                                                color = palette.textPrimary,
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        } else if (isLoading) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = palette.fg)
                            }
                        } else {
                            val searchCards = catalog?.sections?.flatMap { it.items }?.distinctBy { it.url }.orEmpty()
                            if (searchCards.isEmpty()) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text("No matching titles found.", color = palette.textSecondary)
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(
                                        start = 14.dp,
                                        top = 14.dp,
                                        end = 14.dp,
                                        bottom = 14.dp + floatingExtraBottom
                                    ),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    item {
                                        Text(
                                            text = catalog?.pageTitle ?: "Search Results",
                                            color = palette.textPrimary,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    val rows = searchCards.chunked(2)
                                    items(rows) { rowCards ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            rowCards.forEach { card ->
                                                MediaPosterCard(
                                                    card = card,
                                                    imageLoader = imageLoader,
                                                    onClick = { onOpenMedia(card) },
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                            if (rowCards.size == 1) Spacer(Modifier.weight(1f))
                                        }
                                    }
                                    if (catalog?.nextPageUrl != null) {
                                        item {
                                            OutlinedButton(
                                                onClick = { onOpenUrl(catalog.nextPageUrl) },
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text("Next Page", color = palette.fg, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                HomeBottomTab.LIBRARY -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (librarySection == 0) "My List (${myList.size})" else "History (${history.size}/25)",
                                color = palette.textPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            if (librarySection == 1 && history.isNotEmpty()) {
                                TextButton(onClick = onClearHistory) {
                                    Text("Clear History", color = palette.fg, fontSize = 12.5.sp)
                                }
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TopFilterPill(
                                label = "My List (${myList.size})",
                                selected = librarySection == 0,
                                onClick = { librarySection = 0 },
                                modifier = Modifier.weight(1f)
                            )
                            TopFilterPill(
                                label = "Visit History (${history.size})",
                                selected = librarySection == 1,
                                onClick = { librarySection = 1 },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        if (librarySection == 0) {
                            if (myList.isEmpty()) {
                                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "Tap ＋ My List on any movie or series to save it here.",
                                        color = palette.textSecondary,
                                        fontSize = 13.5.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(
                                        start = 14.dp,
                                        top = 14.dp,
                                        end = 14.dp,
                                        bottom = 14.dp + floatingExtraBottom
                                    ),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(myList, key = { it.url }) { item ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(palette.cardBg)
                                                .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                                .clickable { onOpenMyListItem(item) }
                                                .padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            if (item.posterUrl.isNotBlank()) {
                                                AsyncImage(
                                                    model = item.posterUrl,
                                                    imageLoader = imageLoader,
                                                    contentDescription = item.title,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier
                                                        .width(54.dp)
                                                        .aspectRatio(2f / 2.8f)
                                                        .clip(RoundedCornerShape(8.dp))
                                                )
                                            } else {
                                                Box(
                                                    modifier = Modifier
                                                        .width(54.dp)
                                                        .aspectRatio(2f / 2.8f)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(palette.altBg),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(Icons.Rounded.Bookmark, contentDescription = null, tint = palette.fg)
                                                }
                                            }
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = item.title,
                                                    color = palette.textPrimary,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Spacer(Modifier.height(2.dp))
                                                Text(
                                                    text = "${item.type} · ${item.language} · ${item.quality}",
                                                    color = palette.textSecondary,
                                                    fontSize = 11.5.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            IconButton(onClick = { onRemoveMyList(item.url) }) {
                                                Icon(
                                                    imageVector = Icons.Rounded.Delete,
                                                    contentDescription = "Remove",
                                                    tint = palette.textSecondary,
                                                    modifier = Modifier.size(19.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            if (history.isEmpty()) {
                                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "No recent visits yet.",
                                        color = palette.textSecondary,
                                        fontSize = 13.5.sp
                                    )
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(
                                        start = 14.dp,
                                        top = 14.dp,
                                        end = 14.dp,
                                        bottom = 14.dp + floatingExtraBottom
                                    ),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(history, key = { it.url }) { item ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(palette.cardBg)
                                                .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                                .clickable { onOpenHistoryItem(item) }
                                                .padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.History,
                                                contentDescription = null,
                                                tint = palette.fg,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = item.title,
                                                    color = palette.textPrimary,
                                                    fontSize = 13.5.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = "${item.url.removePrefix("https://")} · ${AppSettingsStore.formatRelativeTime(item.timestamp)}",
                                                    color = palette.textSecondary,
                                                    fontSize = 11.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

            if (!settings.floatingNavBar) {
                HorizontalDivider(color = palette.border.copy(alpha = 0.22f))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .background(palette.pageBg),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    BottomNavIconItem(
                        selected = activeBottomTab == HomeBottomTab.HOME,
                        icon = if (activeBottomTab == HomeBottomTab.HOME) Icons.Rounded.Home else Icons.Outlined.Home,
                        contentDescription = "Home",
                        onClick = {
                            if (activeBottomTab == HomeBottomTab.HOME && catalog?.url?.trimEnd('/') != baseMirror) {
                                onOpenUrl(settings.mirrorUrl)
                            } else {
                                activeBottomTab = HomeBottomTab.HOME
                            }
                        }
                    )
                    BottomNavIconItem(
                        selected = activeBottomTab == HomeBottomTab.SEARCH,
                        icon = Icons.Rounded.Search,
                        contentDescription = "Search",
                        onClick = { activeBottomTab = HomeBottomTab.SEARCH }
                    )
                    BottomNavIconItem(
                        selected = activeBottomTab == HomeBottomTab.LIBRARY,
                        icon = Icons.AutoMirrored.Rounded.FormatListBulleted,
                        contentDescription = "My List & History",
                        onClick = { activeBottomTab = HomeBottomTab.LIBRARY }
                    )
                    BottomNavIconItem(
                        selected = false,
                        icon = if (palette.isLightBg) Icons.Rounded.Settings else Icons.Outlined.Settings,
                        contentDescription = "Settings",
                        onClick = onOpenSettings
                    )
                }
            }
        }

        if (settings.floatingNavBar) {
            val customBarColor = remember(settings.floatingNavColorHex, palette.cardBg) {
                settings.floatingNavColorHex?.let {
                    try {
                        Color(android.graphics.Color.parseColor(it))
                    } catch (_: Throwable) {
                        null
                    }
                } ?: palette.cardBg
            }
            val barAlpha = settings.floatingNavAlphaPercent.coerceIn(20, 100) / 100f
            val barShape = RoundedCornerShape(50)
            val barIsLight = if (barAlpha >= 0.45f) {
                ColorUtils.calculateLuminance(customBarColor.toArgb()) > 0.45
            } else {
                palette.isLightBg
            }
            val inactiveTint = if (barIsLight) Color(0xFF3F3F46) else Color(0xFFD4D4D8)
            val activeTint = if (barIsLight && ColorUtils.calculateLuminance(palette.fg.toArgb()) > 0.72) {
                Color(0xFF09090B)
            } else {
                palette.fg
            }

            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = settings.floatingNavSpacingDp.coerceIn(4, 40).dp)
                    .fillMaxWidth(settings.floatingNavWidthPercent.coerceIn(60, 96) / 100f)
                    .height(settings.floatingNavHeightDp.coerceIn(44, 80).dp)
                    .shadow(elevation = 14.dp, shape = barShape, clip = false)
                    .clip(barShape)
                    .background(customBarColor.copy(alpha = barAlpha))
                    .border(1.dp, palette.boxBorder.copy(alpha = 0.42f), barShape),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                BottomNavIconItem(
                    selected = activeBottomTab == HomeBottomTab.HOME,
                    icon = if (activeBottomTab == HomeBottomTab.HOME) Icons.Rounded.Home else Icons.Outlined.Home,
                    contentDescription = "Home",
                    activeTint = activeTint,
                    inactiveTint = inactiveTint,
                    onClick = {
                        if (activeBottomTab == HomeBottomTab.HOME && catalog?.url?.trimEnd('/') != baseMirror) {
                            onOpenUrl(settings.mirrorUrl)
                        } else {
                            activeBottomTab = HomeBottomTab.HOME
                        }
                    }
                )
                BottomNavIconItem(
                    selected = activeBottomTab == HomeBottomTab.SEARCH,
                    icon = Icons.Rounded.Search,
                    contentDescription = "Search",
                    activeTint = activeTint,
                    inactiveTint = inactiveTint,
                    onClick = { activeBottomTab = HomeBottomTab.SEARCH }
                )
                BottomNavIconItem(
                    selected = activeBottomTab == HomeBottomTab.LIBRARY,
                    icon = Icons.AutoMirrored.Rounded.FormatListBulleted,
                    contentDescription = "My List & History",
                    activeTint = activeTint,
                    inactiveTint = inactiveTint,
                    onClick = { activeBottomTab = HomeBottomTab.LIBRARY }
                )
                BottomNavIconItem(
                    selected = false,
                    icon = if (barIsLight) Icons.Rounded.Settings else Icons.Outlined.Settings,
                    contentDescription = "Settings",
                    activeTint = activeTint,
                    inactiveTint = inactiveTint,
                    onClick = onOpenSettings
                )
            }
        }
    }

    if (showCategoriesModal) {
        CategoriesPickerDialog(
            categories = catalog?.categories.orEmpty(),
            currentUrl = catalog?.url.orEmpty(),
            mirrorUrl = settings.mirrorUrl,
            onSelectUrl = { url ->
                showCategoriesModal = false
                activeBottomTab = HomeBottomTab.HOME
                onOpenUrl(url)
            },
            onOpenFallbackWeb = {
                showCategoriesModal = false
                onOpenFallbackWeb()
            },
            onDismiss = { showCategoriesModal = false }
        )
    }
}

@Composable
private fun TopFilterPill(
    label: String,
    selected: Boolean,
    hasCaret: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(50))
            .background(if (selected) palette.fg else Color.Transparent)
            .border(
                width = 1.dp,
                color = if (selected) palette.fg else palette.textSecondary.copy(alpha = 0.55f),
                shape = RoundedCornerShape(50)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Text(
            text = label,
            color = if (selected) palette.onAccent else palette.textPrimary,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (hasCaret) {
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowDown,
                contentDescription = null,
                tint = if (selected) palette.onAccent else palette.textPrimary,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
private fun HeroCoverflowCarousel(
    items: List<MediaCard>,
    imageLoader: ImageLoader,
    onOpenMedia: (MediaCard) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val initialPage = if (items.size >= 3) 1 else 0
    val pagerState = rememberPagerState(initialPage = initialPage, pageCount = { items.size })

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val cardWidth = 196.dp
            val sidePadding = ((maxWidth - cardWidth) / 2).coerceAtLeast(48.dp)

            HorizontalPager(
                state = pagerState,
                contentPadding = PaddingValues(horizontal = sidePadding),
                pageSpacing = 12.dp,
                beyondViewportPageCount = 1,
                modifier = Modifier.fillMaxWidth()
            ) { page ->
                val card = items[page]
                val pageOffset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction).absoluteValue
                val scale = lerpFloat(1f, 0.85f, pageOffset.coerceIn(0f, 1f))
                val alpha = lerpFloat(1f, 0.48f, pageOffset.coerceIn(0f, 1f))

                Box(
                    modifier = Modifier
                        .width(cardWidth)
                        .aspectRatio(0.68f)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            this.alpha = alpha
                        }
                        .clip(RoundedCornerShape(16.dp))
                        .background(palette.cardBg)
                        .border(
                            width = if (pageOffset < 0.35f) 1.2.dp else 0.8.dp,
                            color = if (pageOffset < 0.35f) palette.boxBorder.copy(alpha = 0.7f) else palette.border.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable { onOpenMedia(card) }
                ) {
                    if (card.posterUrl.isNotBlank()) {
                        AsyncImage(
                            model = card.posterUrl,
                            imageLoader = imageLoader,
                            contentDescription = card.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color(0xCC000000))
                                )
                            )
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = card.title,
                                color = Color.White,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 2,
                                textAlign = TextAlign.Center,
                                overflow = TextOverflow.Ellipsis
                            )
                            val sub = listOf(card.language, card.quality).filter { it.isNotBlank() }.joinToString(" · ")
                            if (sub.isNotBlank()) {
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = sub,
                                    color = Color(0xFFD4D4D8),
                                    fontSize = 10.5.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // Dot indicators underneath hero poster (active elongated accent pill)
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.indices.forEach { idx ->
                val isSelected = idx == pagerState.currentPage
                Box(
                    modifier = Modifier
                        .height(5.dp)
                        .width(if (isSelected) 16.dp else 5.dp)
                        .clip(CircleShape)
                        .background(
                            if (isSelected) palette.fg else palette.textSecondary.copy(alpha = 0.35f)
                        )
                )
            }
        }
    }
}

@Composable
private fun ContinueWatchingCard(
    item: HistoryItem,
    imageLoader: ImageLoader,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Column(
        modifier = Modifier
            .width(166.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(palette.cardBg)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 10f)
                .clip(RoundedCornerShape(10.dp))
                .background(palette.altBg)
        ) {
            if (item.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = item.posterUrl,
                    imageLoader = imageLoader,
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = item.title,
            color = palette.textPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
        Spacer(Modifier.height(5.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(palette.textSecondary.copy(alpha = 0.25f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.45f)
                    .fillMaxHeight()
                    .background(palette.fg)
            )
        }
    }
}

@Composable
private fun HomeRailPosterCard(
    card: MediaCard,
    imageLoader: ImageLoader,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Column(
        modifier = Modifier
            .width(118.dp)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 2.8f)
                .clip(RoundedCornerShape(10.dp))
                .background(palette.altBg)
        ) {
            if (card.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = card.posterUrl,
                    imageLoader = imageLoader,
                    contentDescription = card.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.Movie,
                    contentDescription = null,
                    tint = palette.textSecondary,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(28.dp)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = card.title,
            color = palette.textPrimary,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            lineHeight = 15.sp,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun WatchByOttSection(
    platforms: List<OttPlatform>,
    imageLoader: ImageLoader,
    onOpenUrl: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Watch by OTT",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = palette.textPrimary,
            modifier = Modifier.padding(horizontal = 14.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(platforms, key = { it.url }) { ott ->
                val accentColor = remember(ott.accentHex, palette.fg) {
                    if (ott.accentHex.isNotBlank()) {
                        try {
                            Color(android.graphics.Color.parseColor(ott.accentHex))
                        } catch (_: Throwable) {
                            palette.fg
                        }
                    } else {
                        palette.fg
                    }
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(68.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onOpenUrl(ott.url) }
                        .padding(vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (ott.iconUrl.isNotBlank()) {
                            AsyncImage(
                                model = ott.iconUrl,
                                imageLoader = imageLoader,
                                contentDescription = ott.name,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(14.dp))
                            )
                        } else {
                            Text(
                                text = ott.name.take(1).uppercase(),
                                color = accentColor,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = ott.name,
                        color = palette.textPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        textAlign = TextAlign.Center,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun BottomNavIconItem(
    selected: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    activeTint: Color? = null,
    inactiveTint: Color? = null,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val resolvedActive = activeTint ?: palette.fg
    val resolvedInactive = inactiveTint ?: palette.textSecondary
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (selected) resolvedActive else resolvedInactive,
            modifier = Modifier.size(24.dp)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CategoriesPickerDialog(
    categories: List<CategoryChip>,
    currentUrl: String,
    mirrorUrl: String,
    onSelectUrl: (String) -> Unit,
    onOpenFallbackWeb: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = 580.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(palette.cardBg)
                .border(1.2.dp, palette.boxBorder, RoundedCornerShape(18.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Categories & Browse",
                    color = palette.textPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = palette.textPrimary)
                }
            }
            HorizontalDivider(color = palette.border.copy(alpha = 0.2f))

            Column(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onSelectUrl(mirrorUrl) },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.fg, contentColor = palette.onAccent),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Home Feed", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }
                    OutlinedButton(
                        onClick = onOpenFallbackWeb,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.Language, contentDescription = null, tint = palette.fg, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Web Browser", color = palette.textPrimary, fontSize = 12.5.sp)
                    }
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        val active = currentUrl == cat.url
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (active) palette.fg else palette.boxBg)
                                .border(
                                    1.dp,
                                    if (active) palette.fg else palette.boxBorder.copy(alpha = 0.55f),
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { onSelectUrl(cat.url) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = cat.label,
                                color = if (active) palette.onAccent else palette.textPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MediaPosterCard(
    card: MediaCard,
    imageLoader: ImageLoader,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalMovieLinkPalette.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(palette.cardBg)
            .border(1.dp, palette.border.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 2.8f)
                .background(palette.altBg)
        ) {
            if (card.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = card.posterUrl,
                    imageLoader = imageLoader,
                    contentDescription = card.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.Movie,
                    contentDescription = null,
                    tint = palette.textSecondary,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(32.dp)
                )
            }

            if (card.quality.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(palette.fg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = card.quality,
                        color = palette.onAccent,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1
                    )
                }
            }

            if (card.language.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0xD9000000))
                            )
                        )
                        .padding(horizontal = 7.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = card.language,
                        color = Color.White,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Text(
            text = card.title,
            color = palette.textPrimary,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 16.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun ErrorRetryState(
    message: String,
    onRetry: () -> Unit,
    onOpenWeb: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Could not load catalog",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = palette.textPrimary
            )
            Text(
                text = message,
                fontSize = 13.sp,
                color = palette.textSecondary
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.fg,
                        contentColor = palette.onAccent
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Retry", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onOpenWeb,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Open WebView", color = palette.textPrimary)
                }
            }
            OutlinedButton(
                onClick = onOpenSettings,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Update Mirror URL", color = palette.fg)
            }
        }
    }
}

private fun lerpFloat(start: Float, stop: Float, fraction: Float): Float =
    start + (stop - start) * fraction
